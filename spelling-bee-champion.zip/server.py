import http.server
import socketserver
import os
import sys
import json
import urllib.parse
import hashlib
import asyncio
import edge_tts

if sys.stdout:
    sys.stdout.reconfigure(encoding='utf-8', errors='replace')
if sys.stderr:
    sys.stderr.reconfigure(encoding='utf-8', errors='replace')

PORT = int(os.environ.get("PORT", 8000))
DIRECTORY = os.path.dirname(os.path.abspath(__file__))
CACHE_DIR = os.path.join(DIRECTORY, "audio_cache")
os.makedirs(CACHE_DIR, exist_ok=True)

NEURAL_VOICES = {
    "au-male": {
        "id": "en-AU-WilliamMultilingualNeural",
        "name": "Australian Male (William - Neural)",
        "accent": "Australian",
        "gender": "Male",
        "flag": "🇦🇺"
    },
    "au-female": {
        "id": "en-AU-NatashaNeural",
        "name": "Australian Female (Natasha - Neural)",
        "accent": "Australian",
        "gender": "Female",
        "flag": "🇦🇺"
    },
    "in-female": {
        "id": "en-IN-NeerjaNeural",
        "name": "Indian Female (Neerja - Neural)",
        "accent": "Indian",
        "gender": "Female",
        "flag": "🇮🇳"
    },
    "in-male": {
        "id": "en-IN-PrabhatNeural",
        "name": "Indian Male (Prabhat - Neural)",
        "accent": "Indian",
        "gender": "Male",
        "flag": "🇮🇳"
    },
    "gb-male": {
        "id": "en-GB-RyanNeural",
        "name": "British Male (Ryan - Neural)",
        "accent": "British",
        "gender": "Male",
        "flag": "🇬🇧"
    },
    "gb-female": {
        "id": "en-GB-SoniaNeural",
        "name": "British Female (Sonia - Neural)",
        "accent": "British",
        "gender": "Female",
        "flag": "🇬🇧"
    },
    "us-female": {
        "id": "en-US-JennyNeural",
        "name": "US Female (Jenny - Neural)",
        "accent": "American",
        "gender": "Female",
        "flag": "🇺🇸"
    },
    "us-male": {
        "id": "en-US-GuyNeural",
        "name": "US Male (Guy - Neural)",
        "accent": "American",
        "gender": "Male",
        "flag": "🇺🇸"
    }
}

async def generate_speech_audio(text: str, voice_id: str, rate: str, dest_path: str):
    communicate = edge_tts.Communicate(text, voice_id, rate=rate)
    await communicate.save(dest_path)

class TTSAppHandler(http.server.SimpleHTTPRequestHandler):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=DIRECTORY, **kwargs)

    def log_message(self, format, *args):
        # Concise logging to console
        sys.stderr.write(f"[{self.log_date_time_string()}] {format % args}\n")

    def end_headers(self):
        # Enable CORS and caching headers where helpful
        self.send_header('Access-Control-Allow-Origin', '*')
        super().end_headers()

    def do_GET(self):
        parsed = urllib.parse.urlparse(self.path)
        path = parsed.path
        params = urllib.parse.parse_qs(parsed.query)

        # API: Available neural voices
        if path == '/api/voices':
            self.send_response(200)
            self.send_header('Content-Type', 'application/json')
            self.end_headers()
            data = json.dumps(NEURAL_VOICES)
            self.wfile.write(data.encode('utf-8'))
            return

        # API: Speech synthesis endpoint
        if path == '/api/tts':
            voice_key = params.get('voice', ['au-male'])[0]
            text = params.get('text', [''])[0].strip()
            rate_param = params.get('rate', ['0.9'])[0]

            if not text:
                self.send_error(400, "Missing 'text' parameter")
                return

            voice_info = NEURAL_VOICES.get(voice_key, NEURAL_VOICES['au-male'])
            voice_id = voice_info['id']

            # Format rate for edge-tts (e.g. rate=0.8 -> '-20%', rate=0.65 -> '-35%', rate=1.0 -> '+0%')
            try:
                rate_val = float(rate_param)
                rate_pct = int(round((rate_val - 1.0) * 100))
                rate_str = f"{rate_pct:+d}%"
            except ValueError:
                rate_str = "+0%"

            # Cache key based on voice, rate, and text
            cache_hash = hashlib.md5(f"{voice_id}|{rate_str}|{text}".encode('utf-8')).hexdigest()
            cache_file = os.path.join(CACHE_DIR, f"{cache_hash}.mp3")

            if not os.path.exists(cache_file):
                try:
                    asyncio.run(generate_speech_audio(text, voice_id, rate_str, cache_file))
                except Exception as e:
                    self.send_error(500, f"TTS generation error: {e}")
                    return

            try:
                with open(cache_file, 'rb') as f:
                    content = f.read()

                self.send_response(200)
                self.send_header('Content-Type', 'audio/mpeg')
                self.send_header('Content-Length', str(len(content)))
                self.send_header('Cache-Control', 'public, max-age=86400')
                self.end_headers()
                self.wfile.write(content)
            except Exception as e:
                self.send_error(500, f"Error reading cached audio: {e}")
            return

        # Serve static files as normal
        super().do_GET()

class ThreadingServer(socketserver.ThreadingMixIn, socketserver.TCPServer):
    daemon_threads = True
    allow_reuse_address = True

def main():
    os.chdir(DIRECTORY)
    port = PORT
    server = None
    for p in range(PORT, PORT + 10):
        try:
            server = ThreadingServer(("", p), TTSAppHandler)
            port = p
            break
        except OSError:
            continue

    if not server:
        print("Could not bind to any port from 8000 to 8010.")
        sys.exit(1)

    url = f"http://localhost:{port}"
    print(f"==================================================")
    print(f"🐝 Spelling Bee Web App with Neural Voices running at:")
    print(f"   {url}")
    print(f"   Default Voice: 🇦🇺 Australian Male (William - Neural)")
    print(f"   Accents: 🇦🇺 AU (M/F), 🇮🇳 IN (M/F), 🇬🇧 GB (M/F), 🇺🇸 US (M/F)")
    print(f"==================================================")

    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\nShutting down server.")
        server.server_close()

if __name__ == '__main__':
    main()
