# 🐝 BeeSpeller Champion

A voice-enabled web app designed to practice and master 200 Scripps National Spelling Bee study words with authentic accent voices (Australian Male default, Australian Female, Indian Female/Male, British Male/Female, US), letter-by-letter spoken recognition, audio chimes, word masking, and full session customization.

---

## 🚀 Live Cloud Deployment (Render.com)

This app is pre-configured for **Render.com** (Free 24/7 Web Service with SSL/HTTPS).

### Quick Setup Instructions:
1. **Create a GitHub Repository**:
   - Go to [github.com/new](https://github.com/new) and name it `spelling-bee-champion` (public or private).
   - Push or upload the project files to this repository.
2. **Deploy on Render**:
   - Go to [dashboard.render.com](https://dashboard.render.com) and log in (free).
   - Click **New +** > **Web Service**.
   - Select your `spelling-bee-champion` repository.
   - Configure:
     - **Runtime**: `Python 3`
     - **Build Command**: `pip install -r requirements.txt`
     - **Start Command**: `python server.py`
     - **Instance Type**: `Free`
   - Click **Deploy Web Service**.
3. **Open on Chromebook**:
   - In ~1 minute, Render generates your secure live URL:
     `https://spelling-bee-champion-xxxx.onrender.com`
   - Open that URL in Chrome on your daughter's Chromebook, allow microphone access, and bookmark it!

---

## 💻 Running Locally

```bash
uv run python start_app.py
```
Or with plain Python:
```bash
pip install -r requirements.txt
python server.py
```
Open [http://localhost:8000](http://localhost:8000) in your browser.
