// Scripps National Spelling Bee 2026-2027 Word Bank (200 Words)
const DEFAULT_WORDS = [
  {
    "word": "sorceress",
    "grade": 6,
    "difficulty": "easy",
    "pos": "noun",
    "def": "A woman who practices magic or witchcraft.",
    "sentence": "The sorceress cast a gentle spell to guide the travelers home."
  },
  {
    "word": "suspension",
    "grade": 6,
    "difficulty": "easy",
    "pos": "noun",
    "def": "The temporary stopping of an activity or privilege, or a state of being hung.",
    "sentence": "The Golden Gate Bridge is a famous suspension bridge."
  },
  {
    "word": "convertible",
    "grade": 6,
    "difficulty": "easy",
    "pos": "noun / adj",
    "def": "Able to be converted; especially a car with a roof that can be folded back.",
    "sentence": "On sunny afternoons, they loved driving with the convertible top down."
  },
  {
    "word": "collateral",
    "grade": 6,
    "difficulty": "easy",
    "pos": "noun",
    "def": "Something pledged as security for repayment of a loan.",
    "sentence": "The borrower offered real estate as collateral for the bank loan."
  },
  {
    "word": "perimeter",
    "grade": 6,
    "difficulty": "easy",
    "pos": "noun",
    "def": "The continuous line forming the boundary of a closed geometric figure.",
    "sentence": "She measured each side of the garden to calculate its total perimeter."
  },
  {
    "word": "magnesium",
    "grade": 6,
    "difficulty": "easy",
    "pos": "noun",
    "def": "A light, silvery-white metallic element that burns with a brilliant white light.",
    "sentence": "Magnesium is an essential mineral required for plant and human health."
  },
  {
    "word": "hypothermia",
    "grade": 6,
    "difficulty": "easy",
    "pos": "noun",
    "def": "The condition of having an abnormally and dangerously low body temperature.",
    "sentence": "The rescue team wrapped the lost hiker in blankets to treat hypothermia."
  },
  {
    "word": "cosmodrome",
    "grade": 6,
    "difficulty": "hard",
    "pos": "noun",
    "def": "A site or base used for the launch of rockets and spacecraft.",
    "sentence": "The rocket stood poised on the launchpad of the historic cosmodrome."
  },
  {
    "word": "insurrection",
    "grade": 6,
    "difficulty": "hard",
    "pos": "noun",
    "def": "A violent uprising or rebellion against an authority or government.",
    "sentence": "The soldiers quelled the insurrection before the capital was taken."
  },
  {
    "word": "persnickety",
    "grade": 6,
    "difficulty": "hard",
    "pos": "adj",
    "def": "Placing too much emphasis on trivial or minor details; fussy.",
    "sentence": "The persnickety editor checked every punctuation mark twice."
  },
  {
    "word": "predecessor",
    "grade": 6,
    "difficulty": "middle",
    "pos": "noun",
    "def": "A person who held a job or office before the current holder.",
    "sentence": "The new principal paid tribute to the accomplishments of her predecessor."
  },
  {
    "word": "duende",
    "grade": 6,
    "difficulty": "unmarked",
    "pos": "noun",
    "def": "A heightened state of emotion, passion, or charismatic soul in flamenco and art.",
    "sentence": "The guitarist played with such intense duende that the audience was captivated."
  },
  {
    "word": "carrion",
    "grade": 6,
    "difficulty": "middle",
    "pos": "noun",
    "def": "The decaying flesh of dead animals.",
    "sentence": "Vultures circled in the sky searching the plains for carrion."
  },
  {
    "word": "arnica",
    "grade": 6,
    "difficulty": "hard",
    "pos": "noun",
    "def": "A plant of the daisy family used in herbal remedies for soothing bruises.",
    "sentence": "She applied an arnica ointment to her sprained ankle to reduce swelling."
  },
  {
    "word": "iridium",
    "grade": 6,
    "difficulty": "middle",
    "pos": "noun",
    "def": "A hard, dense, corrosion-resistant silvery-yellow chemical element.",
    "sentence": "A thin layer of iridium around the globe suggests an asteroid impact."
  },
  {
    "word": "staccato",
    "grade": 6,
    "difficulty": "easy",
    "pos": "adj / adv",
    "def": "Performed with each note sharply detached or separated from the others.",
    "sentence": "Raindrops hit the metal roof with a rapid, staccato beat."
  },
  {
    "word": "dachshund",
    "grade": 6,
    "difficulty": "middle",
    "pos": "noun",
    "def": "A breed of dog with a long body, very short legs, and drooping ears.",
    "sentence": "The energetic dachshund scampered across the lawn chasing a red ball."
  },
  {
    "word": "glamorous",
    "grade": 6,
    "difficulty": "middle",
    "pos": "adj",
    "def": "Attractive, exciting, and full of charming elegance.",
    "sentence": "She wore a glamorous gown to the annual film gala."
  },
  {
    "word": "singularity",
    "grade": 6,
    "difficulty": "easy",
    "pos": "noun",
    "def": "The state or quality of being singular, unique, or a point of infinite density.",
    "sentence": "Astrophysicists study the gravitational singularity at the center of a black hole."
  },
  {
    "word": "snarkiness",
    "grade": 6,
    "difficulty": "easy",
    "pos": "noun",
    "def": "The quality of being sharply sarcastic, snide, or irritable.",
    "sentence": "His playful snarkiness amused his friends, but annoyed his teachers."
  },
  {
    "word": "initiation",
    "grade": 6,
    "difficulty": "easy",
    "pos": "noun",
    "def": "The act of admitting someone into a group, society, or new phase.",
    "sentence": "The ceremony marked their official initiation into the honor society."
  },
  {
    "word": "precedent",
    "grade": 6,
    "difficulty": "easy",
    "pos": "noun",
    "def": "An earlier event or judicial decision that serves as an example or rule.",
    "sentence": "The Supreme Court's ruling established an important legal precedent."
  },
  {
    "word": "meticulous",
    "grade": 6,
    "difficulty": "easy",
    "pos": "adj",
    "def": "Showing great attention to detail; very careful and precise.",
    "sentence": "The jeweler was meticulous when setting the delicate diamonds."
  },
  {
    "word": "optometrist",
    "grade": 6,
    "difficulty": "hard",
    "pos": "noun",
    "def": "An eye doctor qualified to examine eyes and prescribe corrective lenses.",
    "sentence": "She visited the optometrist to get a new prescription for glasses."
  },
  {
    "word": "arthritis",
    "grade": 6,
    "difficulty": "middle",
    "pos": "noun",
    "def": "Painful inflammation and stiffness of the joints.",
    "sentence": "Regular gentle swimming helped relieve the stiffness caused by arthritis."
  },
  {
    "word": "regolith",
    "grade": 6,
    "difficulty": "middle",
    "pos": "noun",
    "def": "The layer of unconsolidated rocky material covering bedrock, as on the Moon.",
    "sentence": "The Apollo astronauts kicked up clouds of fine lunar regolith as they walked."
  },
  {
    "word": "fascism",
    "grade": 6,
    "difficulty": "middle",
    "pos": "noun",
    "def": "A political philosophy characterized by dictatorial power and strict social control.",
    "sentence": "The historian lectured on the rise of fascism in twentieth-century Europe."
  },
  {
    "word": "Senegal",
    "grade": 6,
    "difficulty": "middle",
    "pos": "noun (proper)",
    "def": "A country located on the coast of West Africa, whose capital is Dakar.",
    "sentence": "The artist traveled to Senegal to explore its rich musical traditions."
  },
  {
    "word": "conscious",
    "grade": 6,
    "difficulty": "easy",
    "pos": "adj",
    "def": "Aware of and responding to one's surroundings; awake and alert.",
    "sentence": "He remained fully conscious and calm despite the sudden power outage."
  },
  {
    "word": "matrilineal",
    "grade": 6,
    "difficulty": "hard",
    "pos": "adj",
    "def": "Based on or tracing kinship through the maternal or mother's line.",
    "sentence": "In several traditional societies, family property passes through a matrilineal system."
  },
  {
    "word": "elliptical",
    "grade": 6,
    "difficulty": "easy",
    "pos": "adj",
    "def": "Having the shape of an ellipse; oval.",
    "sentence": "Planets travel around the sun in elliptical orbits."
  },
  {
    "word": "adrenaline",
    "grade": 6,
    "difficulty": "easy",
    "pos": "noun",
    "def": "A hormone produced in response to stress, fear, or exciting physical exertion.",
    "sentence": "A sudden rush of adrenaline helped the runner sprint across the finish line."
  },
  {
    "word": "rendezvous",
    "grade": 6,
    "difficulty": "easy",
    "pos": "noun",
    "def": "A meeting at an agreed time and place.",
    "sentence": "The explorers set a secret rendezvous point near the fountain."
  },
  {
    "word": "Aeolus",
    "grade": 6,
    "difficulty": "hard",
    "pos": "noun (proper)",
    "def": "In Greek mythology, the divine ruler and keeper of the winds.",
    "sentence": "In the Odyssey, Aeolus gifted Odysseus a bag containing the fierce winds."
  },
  {
    "word": "salamanders",
    "grade": 6,
    "difficulty": "easy",
    "pos": "noun (plural)",
    "def": "Amphibians resembling lizards, with moist skin and a long tail.",
    "sentence": "We found two spotted salamanders hiding under the damp rotting log."
  },
  {
    "word": "fictitious",
    "grade": 6,
    "difficulty": "easy",
    "pos": "adj",
    "def": "Not real or true; invented or fabricated in fiction.",
    "sentence": "Sherlock Holmes is one of literature's most famous fictitious detectives."
  },
  {
    "word": "battalion",
    "grade": 6,
    "difficulty": "easy",
    "pos": "noun",
    "def": "A large military unit consisting of several companies.",
    "sentence": "The commander ordered the infantry battalion to secure the ridge."
  },
  {
    "word": "mascara",
    "grade": 6,
    "difficulty": "easy",
    "pos": "noun",
    "def": "A cosmetic for darkening, lengthening, or thickening the eyelashes.",
    "sentence": "She applied a light coat of waterproof mascara before the performance."
  },
  {
    "word": "materialize",
    "grade": 6,
    "difficulty": "easy",
    "pos": "verb",
    "alternatives": [
      "materialise"
    ],
    "def": "To become actual fact; or to appear unexpectedly as if from nowhere.",
    "sentence": "A friendly cat seemed to materialize out of the evening mist."
  },
  {
    "word": "haddock",
    "grade": 6,
    "difficulty": "middle",
    "pos": "noun",
    "def": "A silvery-gray edible marine fish of the cod family.",
    "sentence": "The coastal diner served delicious crispy haddock with french fries."
  },
  {
    "word": "megahertz",
    "grade": 6,
    "difficulty": "hard",
    "pos": "noun",
    "def": "A unit of frequency equal to one million hertz.",
    "sentence": "The FM radio station broadcasts its audio at 101.5 megahertz."
  },
  {
    "word": "schnauzer",
    "grade": 6,
    "difficulty": "hard",
    "pos": "noun",
    "def": "A German breed of dog with a bristly beard and wiry coat.",
    "sentence": "Their miniature schnauzer greeted every guest with enthusiastic barking."
  },
  {
    "word": "pentathletes",
    "grade": 6,
    "difficulty": "middle",
    "pos": "noun (plural)",
    "def": "Athletes who compete in a pentathlon consisting of five different events.",
    "sentence": "The Olympic pentathletes trained relentlessly in fencing, swimming, and running."
  },
  {
    "word": "pheasants",
    "grade": 6,
    "difficulty": "middle",
    "pos": "noun (plural)",
    "def": "Long-tailed game birds known for the bright plumage of the males.",
    "sentence": "Two colorful ring-necked pheasants burst from the tall prairie grass."
  },
  {
    "word": "reservoir",
    "grade": 6,
    "difficulty": "middle",
    "pos": "noun",
    "def": "A large natural or artificial lake used as a source of water supply.",
    "sentence": "Spring mountain rains filled the municipal water reservoir to capacity."
  },
  {
    "word": "Polaroid",
    "grade": 6,
    "difficulty": "easy",
    "pos": "noun (trademark)",
    "def": "A type of instant camera or the photograph produced by it.",
    "sentence": "She tucked a vintage Polaroid photo of her grandparents into her journal."
  },
  {
    "word": "piteously",
    "grade": 6,
    "difficulty": "middle",
    "pos": "adv",
    "def": "In a manner evoking pity, compassion, or sorrow.",
    "sentence": "The lost puppy whimpered piteously on the rainy doorstep."
  },
  {
    "word": "glaucoma",
    "grade": 6,
    "difficulty": "middle",
    "pos": "noun",
    "def": "An eye condition characterized by increased fluid pressure leading to optic nerve damage.",
    "sentence": "Routine eye exams can detect glaucoma early to protect vision."
  },
  {
    "word": "cemetery",
    "grade": 6,
    "difficulty": "easy",
    "pos": "noun",
    "def": "A burial ground or graveyard.",
    "sentence": "Historic oak trees shaded the oldest monuments in the quiet cemetery."
  },
  {
    "word": "romerillo",
    "grade": 6,
    "difficulty": "middle",
    "pos": "noun",
    "def": "A flowering herbaceous plant or shrub found in tropical and subtropical regions.",
    "sentence": "Herbalists in the Caribbean traditionally steep romerillo leaves into a soothing tea."
  },
  {
    "word": "newt",
    "grade": 7,
    "difficulty": "easy",
    "pos": "noun",
    "def": "A small, slender-bodied amphibian with a moist tail.",
    "sentence": "A bright orange eft, the juvenile stage of an eastern newt, crawled across the moss."
  },
  {
    "word": "lapels",
    "grade": 7,
    "difficulty": "middle",
    "pos": "noun (plural)",
    "def": "The two folded parts on either side of the front of a coat or jacket below the collar.",
    "sentence": "He wore a small enamel American flag pin on the lapels of his suit jacket."
  },
  {
    "word": "mortar",
    "grade": 7,
    "difficulty": "middle",
    "pos": "noun",
    "def": "A mixture of sand, water, and cement used in building to bind stones or bricks.",
    "sentence": "The skilled mason smoothed wet mortar between the brick rows."
  },
  {
    "word": "imperial",
    "grade": 7,
    "difficulty": "easy",
    "pos": "adj",
    "def": "Relating to an empire, emperor, or supreme imperial authority.",
    "sentence": "The visitors admired the grand architecture of the imperial palace."
  },
  {
    "word": "mewling",
    "grade": 7,
    "difficulty": "easy",
    "pos": "verb / adj",
    "def": "Whimpering or crying plaintively like a child or kitten.",
    "sentence": "The tiny stray kitten was heard mewling softly behind the wooden shed."
  },
  {
    "word": "authority",
    "grade": 7,
    "difficulty": "easy",
    "pos": "noun",
    "def": "The power or right to give orders, make decisions, and enforce obedience.",
    "sentence": "The park ranger had the legal authority to close trails during wildfires."
  },
  {
    "word": "lemmings",
    "grade": 7,
    "difficulty": "middle",
    "pos": "noun (plural)",
    "def": "Small, short-tailed Arctic rodents known for dramatic population fluctuations.",
    "sentence": "During peak years, Arctic lemmings forage actively beneath the winter snow."
  },
  {
    "word": "inanimate",
    "grade": 7,
    "difficulty": "easy",
    "pos": "adj",
    "def": "Not alive, lacking physical life; motionless.",
    "sentence": "Rocks, minerals, and wooden chairs are familiar examples of inanimate objects."
  },
  {
    "word": "appetizing",
    "grade": 7,
    "difficulty": "middle",
    "pos": "adj",
    "def": "Appealing to the appetite; invitingly delicious in appearance or aroma.",
    "sentence": "Freshly baked cinnamon rolls gave off an appetizing, sweet fragrance."
  },
  {
    "word": "self-sufficient",
    "grade": 7,
    "difficulty": "easy",
    "pos": "adj",
    "def": "Needing no outside help in satisfying one's basic needs; independent.",
    "sentence": "Their solar-powered homestead was completely self-sufficient for energy and food."
  },
  {
    "word": "tenuous",
    "grade": 7,
    "difficulty": "middle",
    "pos": "adj",
    "def": "Very weak, slight, or fragile; insubstantial.",
    "sentence": "The climber maintained a tenuous grip on the icy granite ledge."
  },
  {
    "word": "procession",
    "grade": 7,
    "difficulty": "easy",
    "pos": "noun",
    "def": "A number of people or vehicles moving forward in an orderly formal manner.",
    "sentence": "A musical brass band led the celebratory parade procession down Main Street."
  },
  {
    "word": "hemisphere",
    "grade": 7,
    "difficulty": "middle",
    "pos": "noun",
    "def": "A half of a sphere; especially half of the Earth.",
    "sentence": "Australia is situated in the Southern Hemisphere."
  },
  {
    "word": "torrential",
    "grade": 7,
    "difficulty": "middle",
    "pos": "adj",
    "def": "Falling rapidly and in copious, torrential quantities.",
    "sentence": "A torrential downpour quickly filled the street gutters with rushing water."
  },
  {
    "word": "cuisine",
    "grade": 7,
    "difficulty": "easy",
    "pos": "noun",
    "def": "A style or method of cooking, especially characteristic of a particular country.",
    "sentence": "Italian cuisine is internationally celebrated for fresh herbs and handmade pasta."
  },
  {
    "word": "modish",
    "grade": 7,
    "difficulty": "middle",
    "pos": "adj",
    "def": "Conforming to or following what is currently popular and fashionable.",
    "sentence": "The boutique displayed modish autumn jackets and stylish leather boots."
  },
  {
    "word": "settee",
    "grade": 7,
    "difficulty": "middle",
    "pos": "noun",
    "def": "A long upholstered seat with a back and arms, for two or more people.",
    "sentence": "Grandmother enjoyed reading mystery novels while seated on the velvet settee."
  },
  {
    "word": "thrummed",
    "grade": 7,
    "difficulty": "easy",
    "pos": "verb",
    "def": "Made a continuous rhythmic humming or vibrating sound.",
    "sentence": "The ship's diesel engines thrummed deep within the ocean liner's hull."
  },
  {
    "word": "generosity",
    "grade": 7,
    "difficulty": "easy",
    "pos": "noun",
    "def": "The quality of being kind, unselfish, and generous.",
    "sentence": "The neighborhood benefited immensely from her generosity toward the local pantry."
  },
  {
    "word": "unrelenting",
    "grade": 7,
    "difficulty": "easy",
    "pos": "adj",
    "def": "Not yielding in strength, severity, or determination; relentless.",
    "sentence": "The marathon runner pushed through the unrelenting heat and wind."
  },
  {
    "word": "persistent",
    "grade": 7,
    "difficulty": "easy",
    "pos": "adj",
    "def": "Continuing firmly or obstinately in a course of action despite difficulty.",
    "sentence": "Her persistent study habits earned her top honors in science class."
  },
  {
    "word": "generator",
    "grade": 7,
    "difficulty": "easy",
    "pos": "noun",
    "def": "A dynamo or mechanical apparatus for converting mechanical energy into electricity.",
    "sentence": "The hospital switched on its backup generator when the storm knocked out power."
  },
  {
    "word": "panoramic",
    "grade": 7,
    "difficulty": "middle",
    "pos": "adj",
    "def": "With a wide and unbroken view of an extensive surrounding area.",
    "sentence": "From the mountain peak, hikers enjoyed a panoramic view of the alpine valley."
  },
  {
    "word": "decisively",
    "grade": 7,
    "difficulty": "easy",
    "pos": "adv",
    "def": "In a manner that shows the ability to make quick decisions firmly and clearly.",
    "sentence": "The soccer captain acted decisively to score the game-winning goal."
  },
  {
    "word": "frequency",
    "grade": 7,
    "difficulty": "easy",
    "pos": "noun",
    "def": "The rate at which something occurs or is repeated over a particular period.",
    "sentence": "The frequency of afternoon thunderstorms increased as summer peaked."
  },
  {
    "word": "sentinels",
    "grade": 7,
    "difficulty": "easy",
    "pos": "noun (plural)",
    "def": "Soldiers or guards whose job is to stand watch and keep look-out.",
    "sentence": "Two stone sentinels stood guard at the ancient castle gates."
  },
  {
    "word": "prospective",
    "grade": 7,
    "difficulty": "easy",
    "pos": "adj",
    "def": "Expected or likely to happen in the future; potential.",
    "sentence": "Campus tour guides welcomed prospective students and their parents."
  },
  {
    "word": "conspicuous",
    "grade": 7,
    "difficulty": "easy",
    "pos": "adj",
    "def": "Standing out so as to be clearly and easily visible.",
    "sentence": "The bright yellow canary was conspicuous among the dark evergreen branches."
  },
  {
    "word": "saxophone",
    "grade": 7,
    "difficulty": "easy",
    "pos": "noun",
    "def": "A brass musical wind instrument with a reed mouthpiece.",
    "sentence": "He played a soulful jazz melody on his tenor saxophone."
  },
  {
    "word": "seminal",
    "grade": 7,
    "difficulty": "middle",
    "pos": "adj",
    "def": "Strongly influencing later developments; groundbreaking and foundational.",
    "sentence": "Albert Einstein published several seminal physics papers in 1905."
  },
  {
    "word": "reluctance",
    "grade": 7,
    "difficulty": "easy",
    "pos": "noun",
    "def": "Unwillingness or hesitation to do something.",
    "sentence": "Despite his initial reluctance, he quickly came to love learning Spanish."
  },
  {
    "word": "sauntered",
    "grade": 7,
    "difficulty": "easy",
    "pos": "verb",
    "def": "Walked in a slow, relaxed, leisurely manner; strolled.",
    "sentence": "The cheerful tourists sauntered leisurely through the botanical gardens."
  },
  {
    "word": "influenza",
    "grade": 7,
    "difficulty": "easy",
    "pos": "noun",
    "def": "A contagious viral infection of the respiratory passages causing fever and aches.",
    "sentence": "Annual vaccinations help protect communities against seasonal influenza."
  },
  {
    "word": "unconscious",
    "grade": 7,
    "difficulty": "easy",
    "pos": "adj",
    "def": "Not awake, aware, or responsive; knocked out or insensible.",
    "sentence": "The boxer remained unconscious for a few seconds before sitting up."
  },
  {
    "word": "embankment",
    "grade": 7,
    "difficulty": "middle",
    "pos": "noun",
    "def": "A stone or earthen wall or mound built to hold back water or support a road.",
    "sentence": "Workers fortified the river embankment to prevent seasonal flooding."
  },
  {
    "word": "burnished",
    "grade": 7,
    "difficulty": "middle",
    "pos": "adj / verb",
    "def": "Polished until smooth and glowing with a bright luster.",
    "sentence": "The antique brass candlestick had a beautiful burnished shine."
  },
  {
    "word": "wallowing",
    "grade": 7,
    "difficulty": "easy",
    "pos": "verb",
    "def": "Rolling about or lying relaxed in mud, water, or dust.",
    "sentence": "Water buffalo spent the hot midday hours wallowing in cool mud pools."
  },
  {
    "word": "arsonists",
    "grade": 7,
    "difficulty": "easy",
    "pos": "noun (plural)",
    "def": "People who deliberately and criminally set fire to property.",
    "sentence": "Detectives gathered evidence to apprehend the reckless arsonists."
  },
  {
    "word": "dominion",
    "grade": 7,
    "difficulty": "middle",
    "pos": "noun",
    "def": "Sovereignty or supreme control over a territory or people.",
    "sentence": "The historic kingdom held vast dominion across the northern seas."
  },
  {
    "word": "Doberman",
    "grade": 7,
    "difficulty": "unmarked",
    "pos": "noun",
    "def": "A sleek, muscular German breed of dog with black and tan markings.",
    "sentence": "Their loyal Doberman guarded the property with alert vigilance."
  },
  {
    "word": "gauntlets",
    "grade": 7,
    "difficulty": "easy",
    "pos": "noun (plural)",
    "def": "Armored or protective gloves covering the hands and wrists.",
    "sentence": "The knight fastened heavy steel gauntlets over his leather riding gloves."
  },
  {
    "word": "auditory",
    "grade": 7,
    "difficulty": "easy",
    "pos": "adj",
    "def": "Relating to the sense of hearing.",
    "sentence": "Listening to birdsong stimulates the brain's complex auditory processing centers."
  },
  {
    "word": "blithely",
    "grade": 7,
    "difficulty": "unmarked",
    "pos": "adv",
    "def": "In a way that shows a casual and cheerful indifference.",
    "sentence": "The carefree hiker walked blithely past warning signs along the steep path."
  },
  {
    "word": "subscription",
    "grade": 7,
    "difficulty": "easy",
    "pos": "noun",
    "def": "An advance payment made to receive regular issues of a magazine or service.",
    "sentence": "She renewed her annual subscription to the national science journal."
  },
  {
    "word": "preconception",
    "grade": 7,
    "difficulty": "unmarked",
    "pos": "noun",
    "def": "An idea or opinion formed beforehand, often without factual basis.",
    "sentence": "Meeting people from other cultures helped challenge his old preconceptions."
  },
  {
    "word": "perpendicular",
    "grade": 7,
    "difficulty": "hard",
    "pos": "adj",
    "def": "At an angle of 90 degrees to a given line, plane, or surface; vertical.",
    "sentence": "The flagpole stood exactly perpendicular to the level concrete courtyard."
  },
  {
    "word": "canter",
    "grade": 7,
    "difficulty": "unmarked",
    "pos": "noun / verb",
    "def": "A three-beat horse gait faster than a trot but slower than a gallop.",
    "sentence": "The equestrian guided her bay horse into a smooth, graceful canter."
  },
  {
    "word": "consulate",
    "grade": 7,
    "difficulty": "middle",
    "pos": "noun",
    "def": "The premises or office officially occupied by a consul in a foreign city.",
    "sentence": "Travelers who lost their passports visited the embassy consulate for assistance."
  },
  {
    "word": "propeller",
    "grade": 7,
    "difficulty": "middle",
    "pos": "noun",
    "def": "A mechanical device with rotating blades that drives an aircraft or ship.",
    "sentence": "The airplane propeller spun rapidly into an invisible blur at takeoff."
  },
  {
    "word": "juniper",
    "grade": 7,
    "difficulty": "easy",
    "pos": "noun",
    "def": "An evergreen shrub or small tree with prickly needle-like leaves and aromatic berries.",
    "sentence": "A sweet, piney scent rose from the crushed blue juniper berries."
  },
  {
    "word": "odorant",
    "grade": 8,
    "difficulty": "middle",
    "pos": "noun",
    "alternatives": [
      "odourant"
    ],
    "def": "A substance that gives off a distinct smell, especially one added to gas for safety.",
    "sentence": "Utility companies add a pungent odorant to natural gas so leaks can be detected."
  },
  {
    "word": "crocheted",
    "grade": 8,
    "difficulty": "easy",
    "pos": "verb / adj",
    "def": "Made with crochet by looping yarn or thread using a hooked needle.",
    "sentence": "Grandma crocheted a cozy pastel blanket for the new baby."
  },
  {
    "word": "apologetic",
    "grade": 8,
    "difficulty": "easy",
    "pos": "adj",
    "def": "Expressing or showing regretful acknowledgment of an offense or fault.",
    "sentence": "He gave an apologetic smile after accidentally bumping into the shelf."
  },
  {
    "word": "Delaware",
    "grade": 8,
    "difficulty": "easy",
    "pos": "noun (proper)",
    "def": "A Mid-Atlantic U.S. state, nicknamed 'The First State'.",
    "sentence": "Delaware was the very first state to ratify the United States Constitution."
  },
  {
    "word": "undulating",
    "grade": 8,
    "difficulty": "easy",
    "pos": "adj / verb",
    "def": "Moving with a smooth wave-like motion; gently rolling hills.",
    "sentence": "Green wheat fields looked like a peaceful undulating sea in the breeze."
  },
  {
    "word": "brazier",
    "grade": 8,
    "difficulty": "middle",
    "pos": "noun",
    "alternatives": [
      "brasier"
    ],
    "def": "A portable metal container designed to hold burning coals or charcoal for heating.",
    "sentence": "The campers gathered around the iron brazier to stay warm in the autumn night."
  },
  {
    "word": "phantasmal",
    "grade": 8,
    "difficulty": "middle",
    "pos": "adj",
    "def": "Relating to or resembling a ghost, phantom, or unreal illusion.",
    "sentence": "A phantasmal white mist hovered silently over the desolate moor."
  },
  {
    "word": "arachnid",
    "grade": 8,
    "difficulty": "easy",
    "pos": "noun",
    "def": "An eight-legged invertebrate animal, including spiders, scorpions, and ticks.",
    "sentence": "A garden spider is a harmless arachnid that feeds on garden pests."
  },
  {
    "word": "affinities",
    "grade": 8,
    "difficulty": "middle",
    "pos": "noun (plural)",
    "def": "Natural likings or sympathy for someone, or close resemblances/connections.",
    "sentence": "Because of her affinities with animals, she decided to study veterinary medicine."
  },
  {
    "word": "embodiment",
    "grade": 8,
    "difficulty": "middle",
    "pos": "noun",
    "def": "A tangible or visible representation of an idea, quality, or feeling.",
    "sentence": "The champion was celebrated as the living embodiment of sportsmanship."
  },
  {
    "word": "porpoises",
    "grade": 8,
    "difficulty": "middle",
    "pos": "noun (plural)",
    "def": "Small, toothed marine cetaceans related to dolphins, typically with blunt snouts.",
    "sentence": "A lively pod of harbor porpoises leaped rhythmically beside the ferry boat."
  },
  {
    "word": "psychological",
    "grade": 8,
    "difficulty": "easy",
    "pos": "adj",
    "def": "Relating to the mental and emotional state of a person.",
    "sentence": "The doctor evaluated both the physical and psychological well-being of the patient."
  },
  {
    "word": "assemblage",
    "grade": 8,
    "difficulty": "middle",
    "pos": "noun",
    "def": "A collection or gathering of things or people.",
    "sentence": "A diverse assemblage of scientists gathered in the lecture hall."
  },
  {
    "word": "leprosy",
    "grade": 8,
    "difficulty": "middle",
    "pos": "noun",
    "def": "A chronic infectious disease caused by Mycobacterium leprae; Hansen's disease.",
    "sentence": "Modern antibiotics have made leprosy completely curable around the world."
  },
  {
    "word": "eureka",
    "grade": 8,
    "difficulty": "middle",
    "pos": "interjection",
    "def": "A cry of joy or satisfaction when one finds or discovers something.",
    "sentence": "'Eureka!' shouted the inventor when the experiment finally succeeded."
  },
  {
    "word": "annelids",
    "grade": 8,
    "difficulty": "middle",
    "pos": "noun (plural)",
    "def": "Segmented worms comprising earthworms, lugworms, and leeches.",
    "sentence": "Earthworms are beneficial annelids that enrich and aerate garden soils."
  },
  {
    "word": "palazzo",
    "grade": 8,
    "difficulty": "middle",
    "pos": "noun",
    "def": "A palatial building or grand residence, especially in Italy.",
    "sentence": "The gondola drifted past a centuries-old Venetian palazzo along the Grand Canal."
  },
  {
    "word": "irrelevant",
    "grade": 8,
    "difficulty": "easy",
    "pos": "adj",
    "def": "Not connected with or relevant to something; beside the point.",
    "sentence": "The judge ruled that the hearsay testimony was completely irrelevant to the case."
  },
  {
    "word": "diplomatically",
    "grade": 8,
    "difficulty": "easy",
    "pos": "adv",
    "def": "In a tactful and sensitive manner dealing with people.",
    "sentence": "She diplomatically deflected the sensitive question with a warm, polite smile."
  },
  {
    "word": "calibrate",
    "grade": 8,
    "difficulty": "middle",
    "pos": "verb",
    "def": "To mark units of measurement or adjust an instrument for accurate readings.",
    "sentence": "The technician had to calibrate the electronic scale before weighing chemicals."
  },
  {
    "word": "credenza",
    "grade": 8,
    "difficulty": "middle",
    "pos": "noun",
    "def": "A sideboard or cupboard, especially one without legs, used for dining or offices.",
    "sentence": "She organized reference books neatly atop the polished walnut credenza."
  },
  {
    "word": "phenomenon",
    "grade": 8,
    "difficulty": "middle",
    "pos": "noun",
    "def": "A remarkable or observed event, fact, or circumstance.",
    "sentence": "The aurora borealis is an extraordinary natural light phenomenon."
  },
  {
    "word": "alleviate",
    "grade": 8,
    "difficulty": "unmarked",
    "pos": "verb",
    "def": "To make suffering, deficiency, or a problem less severe; ease.",
    "sentence": "Applying an ice pack helped alleviate the pain from her twisted knee."
  },
  {
    "word": "legation",
    "grade": 8,
    "difficulty": "middle",
    "pos": "noun",
    "def": "A diplomatic minister and their staff, or the official headquarters of such a mission.",
    "sentence": "The foreign diplomats gathered at the American legation for emergency talks."
  },
  {
    "word": "diffidence",
    "grade": 8,
    "difficulty": "middle",
    "pos": "noun",
    "def": "Modesty or shyness resulting from a lack of self-confidence.",
    "sentence": "Overcoming her initial diffidence, she stepped up to the microphone and sang."
  },
  {
    "word": "butane",
    "grade": 8,
    "difficulty": "middle",
    "pos": "noun",
    "def": "A flammable hydrocarbon gas of the alkane series, stored under pressure as fuel.",
    "sentence": "The portable camping stove was fueled by a small blue cylinder of butane."
  },
  {
    "word": "cataract",
    "grade": 8,
    "difficulty": "easy",
    "pos": "noun",
    "def": "A clouding of the eye lens leading to decreased vision, or a large waterfall.",
    "sentence": "The surgeon performed a routine outpatient procedure to remove her cataract."
  },
  {
    "word": "quiche",
    "grade": 8,
    "difficulty": "unmarked",
    "pos": "noun",
    "def": "A savory open pastry crust filled with baked eggs, cream, cheese, and vegetables.",
    "sentence": "They ordered warm spinach quiche and fresh fruit salad for Sunday brunch."
  },
  {
    "word": "euphemism",
    "grade": 8,
    "difficulty": "middle",
    "pos": "noun",
    "def": "A mild or indirect expression substituted for one considered harsh or blunt.",
    "sentence": "'Passing away' is a gentle euphemism frequently used for the word 'dying'."
  },
  {
    "word": "acolyte",
    "grade": 8,
    "difficulty": "easy",
    "pos": "noun",
    "def": "A person assisting a priest in a religious service; or a devoted assistant.",
    "sentence": "The young acolyte carried the ceremonial candle during the cathedral procession."
  },
  {
    "word": "innocuous",
    "grade": 8,
    "difficulty": "easy",
    "pos": "adj",
    "def": "Not harmful or offensive; harmless.",
    "sentence": "The question seemed innocent and innocuous, but it uncovered a big secret."
  },
  {
    "word": "Tripoli",
    "grade": 8,
    "difficulty": "middle",
    "pos": "noun (proper)",
    "def": "The capital and largest city of Libya in North Africa.",
    "sentence": "Tripoli is an ancient port city situated along the coast of the Mediterranean."
  },
  {
    "word": "neurological",
    "grade": 8,
    "difficulty": "easy",
    "pos": "adj",
    "def": "Relating to the anatomy, functions, and organic disorders of the nervous system.",
    "sentence": "The hospital opened a state-of-the-art neurological research wing."
  },
  {
    "word": "mysticetes",
    "grade": 8,
    "difficulty": "hard",
    "pos": "noun (plural)",
    "def": "Baleen whales, belonging to the suborder Mysticeti, possessing baleen plates.",
    "sentence": "Blue whales and humpbacks are mysticetes that filter tiny krill from seawater."
  },
  {
    "word": "finesse",
    "grade": 8,
    "difficulty": "middle",
    "pos": "noun",
    "def": "Intricate, delicate, and refined skill in action or negotiation.",
    "sentence": "The diplomat handled the delicate peace treaty with remarkable finesse."
  },
  {
    "word": "curriculum",
    "grade": 8,
    "difficulty": "middle",
    "pos": "noun",
    "def": "The subjects comprising a course of study in a school or college.",
    "sentence": "The middle school updated its science curriculum to include robotics."
  },
  {
    "word": "enigmatic",
    "grade": 8,
    "difficulty": "middle",
    "pos": "adj",
    "def": "Difficult to interpret or understand; mysterious.",
    "sentence": "The Mona Lisa is famous worldwide for her subtly enigmatic smile."
  },
  {
    "word": "hypothesis",
    "grade": 8,
    "difficulty": "easy",
    "pos": "noun",
    "def": "A proposed explanation made as a starting point for further investigation.",
    "sentence": "Before conducting the experiment, each student wrote down a clear hypothesis."
  },
  {
    "word": "comprehensible",
    "grade": 8,
    "difficulty": "middle",
    "pos": "adj",
    "def": "Able to be understood; intelligible.",
    "sentence": "The professor made complex quantum physics easily comprehensible to beginners."
  },
  {
    "word": "trenchant",
    "grade": 8,
    "difficulty": "unmarked",
    "pos": "adj",
    "def": "Vigorous or incisive in expression or style; sharp and penetrating.",
    "sentence": "Her trenchant essay analyzed the environmental consequences of deforestation."
  },
  {
    "word": "despondent",
    "grade": 8,
    "difficulty": "unmarked",
    "pos": "adj",
    "def": "In low spirits from loss of hope or courage; dejected.",
    "sentence": "He felt despondent after losing the tournament, but vowed to practice harder."
  },
  {
    "word": "echolocation",
    "grade": 8,
    "difficulty": "hard",
    "pos": "noun",
    "def": "The location of objects by reflected sound, used especially by bats and dolphins.",
    "sentence": "Bats use ultrasonic echolocation to pinpoint nocturnal insects in complete darkness."
  },
  {
    "word": "conflagration",
    "grade": 8,
    "difficulty": "hard",
    "pos": "noun",
    "def": "An extensive, destructive fire that destroys a great deal of land or property.",
    "sentence": "Firefighters battled courageously through the night to halt the advancing conflagration."
  },
  {
    "word": "thermotaxis",
    "grade": 8,
    "difficulty": "hard",
    "pos": "noun",
    "def": "The movement of an organism or cell along a temperature gradient.",
    "sentence": "Nematode worms exhibit positive thermotaxis toward their optimal cultivation temperature."
  },
  {
    "word": "inaugurate",
    "grade": 8,
    "difficulty": "easy",
    "pos": "verb",
    "def": "To admit someone formally to office, or begin an enterprise with a ceremony.",
    "sentence": "The city will inaugurate the new mayor during a formal ceremony in January."
  },
  {
    "word": "bioluminescence",
    "grade": 8,
    "difficulty": "hard",
    "pos": "noun",
    "def": "The emission of light by a living organism, such as a firefly or deep-sea fish.",
    "sentence": "Waves crashing onto the beach sparkled with the blue bioluminescence of plankton."
  },
  {
    "word": "chickadee",
    "grade": 8,
    "difficulty": "easy",
    "pos": "noun",
    "def": "A small North American bird with a dark cap and throat and lively call.",
    "sentence": "A black-capped chickadee landed fearlessly on the snowy bird feeder."
  },
  {
    "word": "asymmetric",
    "grade": 8,
    "difficulty": "easy",
    "pos": "adj",
    "def": "Having two sides or halves that are not the same; lacking symmetry.",
    "sentence": "The modern building features an striking asymmetric roofline."
  },
  {
    "word": "shar-pei",
    "grade": 8,
    "difficulty": "unmarked",
    "pos": "noun",
    "def": "A Chinese breed of dog characterized by deep wrinkles and a blue-black tongue.",
    "sentence": "The wrinkled folds of the shar-pei puppy gave it an endearing expression."
  },
  {
    "word": "endothermy",
    "grade": 8,
    "difficulty": "middle",
    "pos": "noun",
    "def": "The physiological capacity to maintain a warm body temperature internally.",
    "sentence": "Endothermy allows birds and mammals to stay active even in freezing Arctic winters."
  },
  {
    "word": "éclair",
    "grade": 8,
    "difficulty": "easy",
    "pos": "noun",
    "alternatives": [
      "eclair"
    ],
    "def": "An oblong pastry made with choux dough filled with cream and topped with chocolate.",
    "sentence": "She savored a fresh French chocolate éclair at the local bakery."
  },
  {
    "word": "irascibility",
    "grade": 8,
    "difficulty": "middle",
    "pos": "noun",
    "def": "The tendency to be easily angered; irritability or hot-temper.",
    "sentence": "His irascibility flared up whenever his morning train was delayed."
  },
  {
    "word": "foliage",
    "grade": 8,
    "difficulty": "middle",
    "pos": "noun",
    "def": "The leaves of a plant or trees collectively.",
    "sentence": "Tourists flock to Vermont every autumn to admire the vibrant orange foliage."
  },
  {
    "word": "quizzically",
    "grade": 8,
    "difficulty": "middle",
    "pos": "adv",
    "def": "In a questioning, puzzled, or amused manner.",
    "sentence": "The puppy tilted its head quizzically when it heard the strange whistling sound."
  },
  {
    "word": "increments",
    "grade": 8,
    "difficulty": "middle",
    "pos": "noun (plural)",
    "def": "Small regular increases or additions on a fixed scale.",
    "sentence": "The trainer increased the weight in five-pound increments each week."
  },
  {
    "word": "reassurance",
    "grade": 8,
    "difficulty": "unmarked",
    "pos": "noun",
    "def": "The action of removing someone's doubts and fears, or a comforting statement.",
    "sentence": "Her mother's gentle reassurance made her feel confident before the spelling bee."
  },
  {
    "word": "protectorate",
    "grade": 8,
    "difficulty": "unmarked",
    "pos": "noun",
    "def": "A state that is controlled and protected by another sovereign nation.",
    "sentence": "The island territory functioned as a British protectorate during the nineteenth century."
  },
  {
    "word": "pulmonary",
    "grade": 8,
    "difficulty": "hard",
    "pos": "adj",
    "def": "Relating to the lungs.",
    "sentence": "The pulmonary artery transports deoxygenated blood directly to the lungs."
  },
  {
    "word": "approximation",
    "grade": 8,
    "difficulty": "middle",
    "pos": "noun",
    "def": "A value or estimate that is nearly but not exactly correct.",
    "sentence": "Three point one four is a helpful decimal approximation of the number pi."
  },
  {
    "word": "censers",
    "grade": 8,
    "difficulty": "unmarked",
    "pos": "noun (plural)",
    "def": "Vessels in which incense is burned, especially in religious services.",
    "sentence": "Gold censers swung gently on chains, releasing fragrant incense into the air."
  },
  {
    "word": "pathologically",
    "grade": 8,
    "difficulty": "middle",
    "pos": "adv",
    "def": "In a manner caused by or relating to a physical or mental disease; abnormally.",
    "sentence": "He was pathologically incapable of admitting that he had made a mistake."
  },
  {
    "word": "glycerin",
    "grade": 8,
    "difficulty": "easy",
    "pos": "noun",
    "alternatives": [
      "glycerine"
    ],
    "def": "A sweet, colorless, thick liquid used in cosmetics, soaps, and medicines.",
    "sentence": "Glycerin soap is known for being extra moisturizing on sensitive skin."
  },
  {
    "word": "alabaster",
    "grade": 8,
    "difficulty": "unmarked",
    "pos": "noun / adj",
    "def": "A fine-grained, translucent, typically white gypsum or calcite used for carving.",
    "sentence": "Ancient Egyptian artisans carved exquisite vases from pure white alabaster."
  },
  {
    "word": "arugula",
    "grade": 8,
    "difficulty": "unmarked",
    "pos": "noun",
    "def": "A Mediterranean plant with pungent, peppery leaves eaten in salads.",
    "sentence": "She tossed spicy arugula leaves with shaved parmesan and olive oil."
  },
  {
    "word": "vibrometer",
    "grade": 8,
    "difficulty": "middle",
    "pos": "noun",
    "def": "An instrument designed to measure vibrations of machinery or structures.",
    "sentence": "The aerospace engineer used a laser vibrometer to inspect turbine flutter."
  },
  {
    "word": "mayonnaise",
    "grade": 8,
    "difficulty": "easy",
    "pos": "noun",
    "def": "A thick, creamy dressing made of egg yolks, oil, and vinegar or lemon juice.",
    "sentence": "He spread a dollop of creamy mayonnaise onto the turkey sandwich."
  },
  {
    "word": "sputum",
    "grade": 8,
    "difficulty": "unmarked",
    "pos": "noun",
    "def": "A mixture of saliva and mucus coughed up from the respiratory tract.",
    "sentence": "The laboratory analyzed a sputum sample to check for bacterial infection."
  },
  {
    "word": "cerulean",
    "grade": 8,
    "difficulty": "easy",
    "pos": "adj / noun",
    "def": "Deep sky-blue or azure in color.",
    "sentence": "The tropical waters shone with a brilliant, crystal-clear cerulean shade."
  },
  {
    "word": "cul-de-sac",
    "grade": 8,
    "difficulty": "easy",
    "pos": "noun",
    "def": "A street or passage closed at one end; a dead-end street.",
    "sentence": "Children were riding bicycles safely at the end of the quiet cul-de-sac."
  },
  {
    "word": "kerosene",
    "grade": 8,
    "difficulty": "middle",
    "pos": "noun",
    "alternatives": [
      "kerosine"
    ],
    "def": "A light fuel oil obtained by distilling petroleum, used in lamps and jet engines.",
    "sentence": "The vintage lantern glowed warmly with kerosene fuel."
  },
  {
    "word": "Pennsylvania",
    "grade": 8,
    "difficulty": "easy",
    "pos": "noun (proper)",
    "def": "An eastern U.S. state, nicknamed 'The Keystone State'.",
    "sentence": "The Declaration of Independence was signed in Philadelphia, Pennsylvania."
  },
  {
    "word": "ampulla",
    "grade": 8,
    "difficulty": "middle",
    "pos": "noun",
    "def": "A globular dilated part of a canal or duct, as in the inner ear or fallopian tube.",
    "sentence": "Sensory hair cells in the ampulla of the semicircular canal detect head rotation."
  },
  {
    "word": "sensilla",
    "grade": 8,
    "difficulty": "middle",
    "pos": "noun (plural)",
    "def": "Simple sensory receptors on insects consisting of a modified spine or pore.",
    "sentence": "Tiny sensilla on insect antennae detect minute chemical odors in the breeze."
  },
  {
    "word": "eponymous",
    "grade": 8,
    "difficulty": "hard",
    "pos": "adj",
    "def": "Giving one's name to a book, place, or institution, or named after someone.",
    "sentence": "The Beatles released their eponymous double album, commonly known as The White Album."
  },
  {
    "word": "Presbyterian",
    "grade": 8,
    "difficulty": "easy",
    "pos": "adj / noun",
    "def": "Relating to a Reformed Protestant denomination governed by elders.",
    "sentence": "The historic stone Presbyterian church sat facing the central village green."
  },
  {
    "word": "Sierra Leone",
    "grade": 8,
    "difficulty": "hard",
    "pos": "noun (proper)",
    "def": "A coastal country located in West Africa, whose capital is Freetown.",
    "sentence": "Freetown is the lively coastal capital and largest port of Sierra Leone."
  },
  {
    "word": "Eritrea",
    "grade": 8,
    "difficulty": "middle",
    "pos": "noun (proper)",
    "def": "A northeast African country situated on the Red Sea coast.",
    "sentence": "Asmara is the high-elevation, architecturally striking capital of Eritrea."
  },
  {
    "word": "forsythia",
    "grade": 8,
    "difficulty": "middle",
    "pos": "noun",
    "def": "An ornamental deciduous shrub producing bright yellow flowers in early spring.",
    "sentence": "Golden blooms on the forsythia bush were the first cheerful sign of spring."
  },
  {
    "word": "salicylic acid",
    "grade": 8,
    "difficulty": "easy",
    "pos": "noun",
    "def": "A crystalline organic carboxylic acid used in skincare and aspirin synthesis.",
    "sentence": "Dermatologists often recommend salicylic acid cleansers to unclog pores."
  },
  {
    "word": "stomatopods",
    "grade": 8,
    "difficulty": "hard",
    "pos": "noun (plural)",
    "def": "Marine crustaceans of the order Stomatopoda, including mantis shrimps.",
    "sentence": "Stomatopods possess powerful predatory claws that can strike with blinding speed."
  },
  {
    "word": "frankincense",
    "grade": 8,
    "difficulty": "hard",
    "pos": "noun",
    "def": "An aromatic gum resin from Arabian trees, burned as incense and used in perfumes.",
    "sentence": "Ancient trading caravans transported precious frankincense across the desert routes."
  },
  {
    "word": "solenodon",
    "grade": 8,
    "difficulty": "hard",
    "pos": "noun",
    "def": "A nocturnal, venomous, insectivorous mammal found in Cuba and Hispaniola.",
    "sentence": "The rare Hispaniolan solenodon is one of the world's few venomous mammals."
  },
  {
    "word": "lactobacillus",
    "grade": 8,
    "difficulty": "hard",
    "pos": "noun",
    "def": "A genus of rod-shaped, beneficial bacteria that produce lactic acid.",
    "sentence": "Lactobacillus cultures are active ingredients in the fermentation of traditional yogurt."
  },
  {
    "word": "vibrissae",
    "grade": 8,
    "difficulty": "hard",
    "pos": "noun (plural)",
    "def": "Stiff tactile hairs or whiskers growing around the nostrils or eyes of animals.",
    "sentence": "The cat's sensitive vibrissae helped it navigate through narrow spaces in the dark."
  },
  {
    "word": "a cappella",
    "grade": 8,
    "difficulty": "easy",
    "pos": "adj / adv",
    "alternatives": [
      "acappella"
    ],
    "def": "Choral or vocal music sung without any instrumental accompaniment.",
    "sentence": "The university choir performed a stunning a cappella arrangement of the folk song."
  },
  {
    "word": "Amharic",
    "grade": 8,
    "difficulty": "middle",
    "pos": "noun (proper)",
    "def": "A Semitic language that is the official working language of Ethiopia.",
    "sentence": "Amharic is written using a unique writing system known as the Ge'ez script."
  },
  {
    "word": "Gloucester",
    "grade": 8,
    "difficulty": "middle",
    "pos": "noun (proper)",
    "def": "A historic cathedral city in England, or a famous fishing port city in Massachusetts.",
    "sentence": "Gloucester, Massachusetts is renowned as one of America's oldest seaport communities."
  },
  {
    "word": "prosciutto",
    "grade": 8,
    "difficulty": "easy",
    "pos": "noun",
    "def": "Italian dry-cured ham that is usually thinly sliced and served uncooked.",
    "sentence": "Slices of savory prosciutto were wrapped around sweet, chilled melon wedges."
  },
  {
    "word": "chitinous",
    "grade": 8,
    "difficulty": "middle",
    "pos": "adj",
    "def": "Formed or made of chitin, the tough substance forming arthropod exoskeletons.",
    "sentence": "The beetle was protected by a durable, hard chitinous outer shell."
  },
  {
    "word": "trichobothria",
    "grade": 8,
    "difficulty": "hard",
    "pos": "noun (plural)",
    "def": "Elongate sensory setae found on arachnids that detect subtle air currents.",
    "sentence": "Delicate trichobothria on the scorpion's pedipalps alert it to approaching prey."
  },
  {
    "word": "Cappadocia",
    "grade": 8,
    "difficulty": "hard",
    "pos": "noun (proper)",
    "def": "A historical region in central Turkey famous for distinctive 'fairy chimney' rock formations.",
    "sentence": "Hundreds of colorful hot-air balloons float over the canyons of Cappadocia at sunrise."
  },
  {
    "word": "Bildungsroman",
    "grade": 8,
    "difficulty": "hard",
    "pos": "noun",
    "alternatives": [
      "bildungsroman"
    ],
    "def": "A novel dealing with one person's formative years or moral/spiritual growth; a coming-of-age story.",
    "sentence": "To Kill a Mockingbird is often studied as a classic example of a Bildungsroman."
  },
  {
    "word": "electrolytes",
    "grade": 8,
    "difficulty": "easy",
    "pos": "noun (plural)",
    "def": "Minerals in body fluids that carry an electric charge and maintain fluid balance.",
    "sentence": "Drinking sports beverages with electrolytes helps rehydrate athletes after vigorous workouts."
  },
  {
    "word": "ototoxic",
    "grade": 8,
    "difficulty": "middle",
    "pos": "adj",
    "def": "Having a toxic or damaging effect on the ear or its nerve supply.",
    "sentence": "Doctors carefully monitored the dosage because the medication could be ototoxic."
  },
  {
    "word": "Aphrodite",
    "grade": 8,
    "difficulty": "easy",
    "pos": "noun (proper)",
    "def": "The ancient Greek goddess of love, beauty, passion, and procreation.",
    "sentence": "In Greek legend, Aphrodite arose from the sea foam near the island of Cyprus."
  },
  {
    "word": "bogong moth",
    "grade": 8,
    "difficulty": "middle",
    "pos": "noun",
    "def": "An Australian noctuid moth that undertakes extensive long-distance annual migrations.",
    "sentence": "Millions of bogong moths migrate to the cool Australian Alps during hot summers."
  },
  {
    "word": "yakuza",
    "grade": 8,
    "difficulty": "middle",
    "pos": "noun",
    "def": "A Japanese organized crime syndicate, or a member of such a syndicate.",
    "sentence": "The detective thriller focused on international investigations into the yakuza."
  },
  {
    "word": "Krio",
    "grade": 8,
    "difficulty": "middle",
    "pos": "noun (proper)",
    "def": "An English-based creole language spoken throughout Sierra Leone.",
    "sentence": "Krio serves as the widespread lingua franca among diverse communities across Sierra Leone."
  },
  {
    "word": "Addis Ababa",
    "grade": 8,
    "difficulty": "hard",
    "pos": "noun (proper)",
    "def": "The highland capital city and largest urban center of Ethiopia.",
    "sentence": "Addis Ababa serves as the diplomatic headquarters of the African Union."
  },
  {
    "word": "spes phthisica",
    "grade": 8,
    "difficulty": "hard",
    "pos": "noun",
    "def": "An unrealistic, euphoric state of optimism often observed in patients with pulmonary tuberculosis.",
    "sentence": "Historical physicians documented spes phthisica in poets who remained cheerful despite chronic illness."
  }
];
