import os
import sys
import webbrowser

DIRECTORY = os.path.dirname(os.path.abspath(__file__))

if __name__ == '__main__':
    os.chdir(DIRECTORY)
    # Open browser automatically after short delay
    webbrowser.open("http://localhost:8000")
    import server
    server.main()
