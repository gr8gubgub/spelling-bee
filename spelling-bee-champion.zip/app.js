// ==========================================
// BeeSpeller Champion - Main Application Logic
// ==========================================

let wordsBank = [];
let activeQuizList = [];
let currentIndex = 0;
let currentScore = 0;
let currentSpelledLetters = "";
let baseSpelledLetters = "";
let lastCommittedResultIndex = -1;
let shouldKeepListening = false;
let currentSessionResults = [];
let speechRecognizer = null;
let isRecording = false;
let selectedVoice = null;
let customDifficulties = {};

// Quiz Configuration State
let configWordCount = 5;
let configDifficulty = 'all';
let configGrade = 'all';

// Audio Context for Chimes (Web Audio API)
let audioCtx = null;

function getAudioContext() {
  if (!audioCtx) {
    const AudioContextClass = window.AudioContext || window.webkitAudioContext;
    if (AudioContextClass) {
      audioCtx = new AudioContextClass();
    }
  }
  if (audioCtx && audioCtx.state === 'suspended') {
    audioCtx.resume();
  }
  return audioCtx;
}

// Play celebratory or error sound effect
function playChime(isSuccess) {
  try {
    const ctx = getAudioContext();
    if (!ctx) return;

    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.connect(gain);
    gain.connect(ctx.destination);

    const now = ctx.currentTime;
    if (isSuccess) {
      // Cheerful major chord arpeggio
      osc.type = 'triangle';
      osc.frequency.setValueAtTime(523.25, now); // C5
      osc.frequency.setValueAtTime(659.25, now + 0.1); // E5
      osc.frequency.setValueAtTime(783.99, now + 0.2); // G5
      osc.frequency.setValueAtTime(1046.50, now + 0.3); // C6
      gain.gain.setValueAtTime(0.3, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.7);
      osc.start(now);
      osc.stop(now + 0.7);
    } else {
      // Gentle soft low error tone
      osc.type = 'sine';
      osc.frequency.setValueAtTime(320, now);
      osc.frequency.exponentialRampToValueAtTime(180, now + 0.35);
      gain.gain.setValueAtTime(0.25, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.4);
      osc.start(now);
      osc.stop(now + 0.4);
    }
  } catch (e) {
    console.warn("Audio chime error:", e);
  }
}

// ==========================================
// Initialization & Voice Setup
// ==========================================
document.addEventListener("DOMContentLoaded", async () => {
  loadCustomDifficulties();
  await ensureWordsLoaded();
  setupVoices();
  setupSpeechRecognition();
  loadStats();
  loadAudioOnlyPreference();

  // Keyboard navigation
  window.addEventListener('keydown', handleGlobalKeydown);
});

async function ensureWordsLoaded() {
  if (typeof DEFAULT_WORDS !== 'undefined' && Array.isArray(DEFAULT_WORDS) && DEFAULT_WORDS.length > 0) {
    initializeWordsBank();
    updateSetupCounts();
    renderWordBank();
    return;
  }

  // Fallback 1: Fetch words.json directly from server
  try {
    const res = await fetch('words.json');
    if (res.ok) {
      const data = await res.json();
      if (Array.isArray(data) && data.length > 0) {
        window.DEFAULT_WORDS = data;
        initializeWordsBank();
        updateSetupCounts();
        renderWordBank();
        return;
      }
    }
  } catch (e) {
    console.warn("Could not fetch words.json fallback:", e);
  }

  // Fallback 2: Polling retry every 100ms up to 30 times (3 seconds)
  let attempts = 0;
  const interval = setInterval(() => {
    attempts++;
    if (typeof DEFAULT_WORDS !== 'undefined' && Array.isArray(DEFAULT_WORDS) && DEFAULT_WORDS.length > 0) {
      clearInterval(interval);
      initializeWordsBank();
      updateSetupCounts();
      renderWordBank();
    } else if (attempts > 30) {
      clearInterval(interval);
      console.error("Failed to load spelling bee words bank after 30 attempts.");
    }
  }, 100);
}

function loadAudioOnlyPreference() {
  try {
    const stored = localStorage.getItem('bee_audio_only_clues');
    if (stored !== null) {
      toggleAudioOnlyPreference(stored === 'true');
    }
  } catch (e) {}
}

function loadCustomDifficulties() {
  try {
    const stored = localStorage.getItem('bee_custom_difficulties');
    if (stored) {
      customDifficulties = JSON.parse(stored);
    }
  } catch (e) {
    customDifficulties = {};
  }
}

function saveCustomDifficulty(word, newDiff) {
  customDifficulties[word] = newDiff;
  try {
    localStorage.setItem('bee_custom_difficulties', JSON.stringify(customDifficulties));
  } catch (e) {}
  // Update words bank in memory
  const found = wordsBank.find(w => w.word.toLowerCase() === word.toLowerCase());
  if (found) {
    found.difficulty = newDiff;
  }
  updateSetupCounts();
}

function initializeWordsBank() {
  const base = (typeof DEFAULT_WORDS !== 'undefined' && Array.isArray(DEFAULT_WORDS)) ? DEFAULT_WORDS : [];
  wordsBank = base.map(item => {
    const custom = customDifficulties[item.word];
    return {
      ...item,
      difficulty: custom || item.difficulty || 'unmarked'
    };
  });
}

function updateSetupCounts() {
  const allCount = wordsBank.length;
  const easyCount = wordsBank.filter(w => w.difficulty === 'easy').length;
  const midCount = wordsBank.filter(w => w.difficulty === 'middle').length;
  const hardCount = wordsBank.filter(w => w.difficulty === 'hard').length;

  const countAllEl = document.getElementById('count-all');
  const countEasyEl = document.getElementById('count-easy');
  const countMiddleEl = document.getElementById('count-middle');
  const countHardEl = document.getElementById('count-hard');

  if (countAllEl) countAllEl.innerText = `${allCount} words`;
  if (countEasyEl) countEasyEl.innerText = `${easyCount} words`;
  if (countMiddleEl) countMiddleEl.innerText = `${midCount} words`;
  if (countHardEl) countHardEl.innerText = `${hardCount} words`;

  // Update available pool note
  updatePoolAvailableNote();
}

function updatePoolAvailableNote() {
  const pool = getFilteredPool();
  const el = document.getElementById('pool-available-note');
  if (el) {
    el.innerText = `${pool.length} available in chosen filter`;
  }
}

// ==========================================
// Speech Synthesis & Neural Accent Voices
// ==========================================
const NEURAL_VOICE_OPTIONS = [
  { key: 'neural:au-male', name: '🇦🇺 Australian Male (William - Neural)', preview: "G'day! Welcome to the BeeSpeller Champion spelling bee.", default: true },
  { key: 'neural:au-female', name: '🇦🇺 Australian Female (Natasha - Neural)', preview: "Hello! Welcome to the BeeSpeller Champion spelling bee." },
  { key: 'neural:in-female', name: '🇮🇳 Indian Female (Neerja - Neural)', preview: "Namaste! Welcome to the BeeSpeller Champion spelling bee." },
  { key: 'neural:in-male', name: '🇮🇳 Indian Male (Prabhat - Neural)', preview: "Namaste! Welcome to the BeeSpeller Champion spelling bee." },
  { key: 'neural:gb-male', name: '🇬🇧 British Male (Ryan - Neural)', preview: "Good day! Welcome to the BeeSpeller Champion spelling bee." },
  { key: 'neural:gb-female', name: '🇬🇧 British Female (Sonia - Neural)', preview: "Good day! Welcome to the BeeSpeller Champion spelling bee." },
  { key: 'neural:us-female', name: '🇺🇸 US Female (Jenny - Neural)', preview: "Hello! Welcome to the BeeSpeller Champion spelling bee." },
  { key: 'neural:us-male', name: '🇺🇸 US Male (Guy - Neural)', preview: "Hello! Welcome to the BeeSpeller Champion spelling bee." }
];

let selectedVoiceKey = 'neural:au-male';
let selectedNativeVoice = null;
let activeAudio = null;

function loadSelectedVoicePreference() {
  try {
    const saved = localStorage.getItem('bee_selected_voice');
    if (saved) {
      selectedVoiceKey = saved;
    } else {
      selectedVoiceKey = 'neural:au-male';
    }
  } catch (e) {
    selectedVoiceKey = 'neural:au-male';
  }
}

function saveSelectedVoicePreference(key) {
  selectedVoiceKey = key;
  try {
    localStorage.setItem('bee_selected_voice', key);
  } catch (e) {}
}

function setupVoices() {
  loadSelectedVoicePreference();

  function populateVoiceDropdowns() {
    const selects = [
      document.getElementById('voice-select'),
      document.getElementById('quiz-voice-select')
    ].filter(Boolean);

    if (selects.length === 0) return;

    selects.forEach(select => {
      select.innerHTML = '';

      // 1. Neural Voices Group
      const neuralGroup = document.createElement('optgroup');
      neuralGroup.label = '✨ High-Quality Neural Voices (Accents)';
      NEURAL_VOICE_OPTIONS.forEach(opt => {
        const optionEl = document.createElement('option');
        optionEl.value = opt.key;
        optionEl.textContent = opt.name + (opt.default ? ' [Default]' : '');
        neuralGroup.appendChild(optionEl);
      });
      select.appendChild(neuralGroup);

      // 2. Browser Native Voices Group (if supported)
      if ('speechSynthesis' in window) {
        const nativeVoices = window.speechSynthesis.getVoices();
        const engVoices = nativeVoices.filter(v => v.lang.startsWith('en'));
        const listToUse = engVoices.length ? engVoices : nativeVoices;

        if (listToUse.length > 0) {
          const nativeGroup = document.createElement('optgroup');
          nativeGroup.label = '🌐 Browser System Voices';
          listToUse.forEach(v => {
            const optionEl = document.createElement('option');
            optionEl.value = `native:${v.name}`;
            optionEl.textContent = `${v.name} (${v.lang})`;
            nativeGroup.appendChild(optionEl);
          });
          select.appendChild(nativeGroup);
        }
      }

      // Restore selected value
      select.value = selectedVoiceKey;
      if (!select.value && select.options.length > 0) {
        select.value = 'neural:au-male';
        selectedVoiceKey = 'neural:au-male';
      }
    });

    updateSelectedNativeVoice();
  }

  populateVoiceDropdowns();

  if ('speechSynthesis' in window && window.speechSynthesis.onvoiceschanged !== undefined) {
    window.speechSynthesis.onvoiceschanged = populateVoiceDropdowns;
  }

  // Listeners on both setup and quiz selects to keep them synchronized
  ['voice-select', 'quiz-voice-select'].forEach(id => {
    const el = document.getElementById(id);
    if (el) {
      el.addEventListener('change', (e) => {
        const newKey = e.target.value;
        saveSelectedVoicePreference(newKey);
        updateSelectedNativeVoice();

        // Sync other select
        ['voice-select', 'quiz-voice-select'].forEach(otherId => {
          const otherEl = document.getElementById(otherId);
          if (otherEl && otherEl !== el) {
            otherEl.value = newKey;
          }
        });
      });
    }
  });
}

function updateSelectedNativeVoice() {
  if (selectedVoiceKey.startsWith('native:') && 'speechSynthesis' in window) {
    const voiceName = selectedVoiceKey.replace('native:', '');
    const voices = window.speechSynthesis.getVoices();
    selectedNativeVoice = voices.find(v => v.name === voiceName) || null;
  } else {
    selectedNativeVoice = null;
  }
}

// Stop any currently playing audio or speech synthesis immediately
function stopCurrentSpeech() {
  if (activeAudio) {
    try {
      activeAudio.pause();
      activeAudio.currentTime = 0;
    } catch (e) {}
    activeAudio = null;
  }
  if ('speechSynthesis' in window) {
    try {
      window.speechSynthesis.cancel();
    } catch (e) {}
  }
}

function speakText(text, rate = 0.9, onEndCallback = null) {
  if (!text) return;
  stopCurrentSpeech();

  // If using Neural Server Voice
  if (selectedVoiceKey.startsWith('neural:')) {
    const voiceCode = selectedVoiceKey.replace('neural:', '');
    const url = `/api/tts?voice=${encodeURIComponent(voiceCode)}&text=${encodeURIComponent(text)}&rate=${rate}`;
    const audio = new Audio(url);
    activeAudio = audio;

    audio.onended = () => {
      activeAudio = null;
      if (onEndCallback) onEndCallback();
    };

    audio.onerror = (err) => {
      console.warn("Neural audio playback failed, falling back to Web Speech API:", err);
      activeAudio = null;
      speakWithWebSpeech(text, rate, onEndCallback);
    };

    const playPromise = audio.play();
    if (playPromise !== undefined) {
      playPromise.catch(err => {
        console.warn("Audio play() interrupted or blocked:", err);
        // Fallback if audio policy blocked
        speakWithWebSpeech(text, rate, onEndCallback);
      });
    }
  } else {
    // Native browser voice
    speakWithWebSpeech(text, rate, onEndCallback);
  }
}

function speakWithWebSpeech(text, rate = 0.9, onEndCallback = null) {
  if (!('speechSynthesis' in window)) return;
  const utterance = new SpeechSynthesisUtterance(text);
  if (selectedNativeVoice) {
    utterance.voice = selectedNativeVoice;
  }
  utterance.rate = rate;
  utterance.pitch = 1.0;
  if (onEndCallback) {
    utterance.onend = onEndCallback;
  }
  window.speechSynthesis.speak(utterance);
}

// Preview button test speech
function testCurrentVoice() {
  const current = NEURAL_VOICE_OPTIONS.find(o => o.key === selectedVoiceKey);
  const sample = current ? current.preview : "Hello! Welcome to the BeeSpeller Champion spelling bee.";
  speakText(sample, 0.9);
}

// Speak the word letter-by-letter slowly
function speakLetterByLetter(word, callback) {
  stopCurrentSpeech();

  const cleanLetters = word.toUpperCase().split('').map(ch => {
    if (ch === ' ') return 'space';
    if (ch === '-') return 'hyphen';
    return ch;
  });

  if (selectedVoiceKey.startsWith('neural:')) {
    // Neural voices benefit from punctuated pauses between letters
    const spelled = cleanLetters.join('... ');
    const fullText = `Incorrect. The correct spelling is: ${spelled}... ${word}.`;
    speakText(fullText, 0.75, callback);
  } else {
    const spelledText = cleanLetters.join(',  ');
    const fullText = `Incorrect. The correct spelling is: ${spelledText}.  ${word}.`;
    speakWithWebSpeech(fullText, 0.65, callback);
  }
}

// ==========================================
// Speech Recognition (Microphone Voice Spelling)
// ==========================================
function setupSpeechRecognition() {
  const SpeechRec = window.SpeechRecognition || window.webkitSpeechRecognition;
  if (!SpeechRec) {
    console.warn("Speech Recognition API not supported in this browser.");
    const micLabel = document.getElementById('mic-status-label');
    if (micLabel) {
      micLabel.innerText = "Voice recognition not supported in this browser. Use keyboard below!";
    }
    return;
  }

  speechRecognizer = new SpeechRec();
  speechRecognizer.continuous = true;
  speechRecognizer.interimResults = true;
  speechRecognizer.lang = 'en-US';

  speechRecognizer.onstart = () => {
    isRecording = true;
    lastCommittedResultIndex = -1;
    updateMicUI(true);
  };

  speechRecognizer.onend = () => {
    isRecording = false;
    // If user hasn't explicitly stopped mic or submitted, keep listening so pauses between letters don't stop recognition
    if (shouldKeepListening) {
      lastCommittedResultIndex = -1;
      try {
        speechRecognizer.start();
        return;
      } catch (e) {
        setTimeout(() => {
          if (shouldKeepListening) {
            try { speechRecognizer.start(); } catch (err) {}
          }
        }, 200);
      }
    }
    updateMicUI(false);
  };

  speechRecognizer.onerror = (event) => {
    console.warn("Speech recognition error:", event.error);
    if (event.error === 'no-speech' && shouldKeepListening) {
      // Natural pause between letters, onend will automatically re-listen
      return;
    }
    isRecording = false;
    updateMicUI(false);
  };

  speechRecognizer.onresult = (event) => {
    let newFinalTranscript = '';
    let interimTranscript = '';

    for (let i = 0; i < event.results.length; ++i) {
      if (event.results[i].isFinal) {
        if (i > lastCommittedResultIndex) {
          newFinalTranscript += event.results[i][0].transcript + ' ';
          lastCommittedResultIndex = i;
        }
      } else {
        interimTranscript += event.results[i][0].transcript + ' ';
      }
    }

    if (newFinalTranscript.trim()) {
      const finalLetters = parseTranscriptToLetters(newFinalTranscript);
      if (finalLetters) {
        baseSpelledLetters += finalLetters;
      }
    }

    const interimLetters = interimTranscript.trim() ? parseTranscriptToLetters(interimTranscript) : '';
    currentSpelledLetters = (baseSpelledLetters + interimLetters).toLowerCase();
    renderLetterBoxes();
  };
}

// Dictionary mapping spoken letter names, homophones, and phonetic names to actual letters
const PHONETIC_LETTER_MAP = {
  'a': 'a', 'ay': 'a', 'aye': 'a', 'hey': 'a',
  'b': 'b', 'bee': 'b', 'be': 'b',
  'c': 'c', 'see': 'c', 'sea': 'c', 'si': 'c', 'cee': 'c',
  'd': 'd', 'dee': 'd',
  'e': 'e', 'ee': 'e',
  'f': 'f', 'ef': 'f', 'eff': 'f',
  'g': 'g', 'gee': 'g', 'jee': 'g',
  'h': 'h', 'aitch': 'h', 'ach': 'h', 'hate': 'h', 'eight': 'h',
  'i': 'i', 'eye': 'i', 'aye': 'i', 'ai': 'i',
  'j': 'j', 'jay': 'j',
  'k': 'k', 'kay': 'k', 'ok': 'k',
  'l': 'l', 'el': 'l', 'ell': 'l',
  'm': 'm', 'em': 'm',
  'n': 'n', 'en': 'n', 'an': 'n', 'and': 'n', 'in': 'n',
  'o': 'o', 'oh': 'o',
  'p': 'p', 'pee': 'p', 'pea': 'p',
  'q': 'q', 'cue': 'q', 'queue': 'q',
  'r': 'r', 'are': 'r', 'ar': 'r', 'our': 'r',
  's': 's', 'es': 's', 'ess': 's', 'yes': 's',
  't': 't', 'tee': 't', 'tea': 't',
  'u': 'u', 'you': 'u', 'yu': 'u',
  'v': 'v', 'vee': 'v', 'we': 'v',
  'w': 'w', 'double u': 'w', 'double-u': 'w', 'doubleyou': 'w',
  'x': 'x', 'ex': 'x', 'axe': 'x',
  'y': 'y', 'why': 'y', 'wye': 'y',
  'z': 'z', 'zee': 'z', 'zed': 'z',
  'space': ' ', 'hyphen': '-', 'dash': '-', 'apostrophe': "'"
};

function parseTranscriptToLetters(transcript) {
  if (!transcript) return '';
  let clean = transcript.toLowerCase().trim();

  // Normalize punctuation dots/commas
  clean = clean.replace(/[.,!?]/g, ' ');

  // Hyphenated letters e.g. "s-c-h"
  if (clean.includes('-')) {
    const parts = clean.split('-').map(s => s.trim()).filter(Boolean);
    if (parts.length > 1) {
      return parts.map(p => PHONETIC_LETTER_MAP[p] || (p.length === 1 ? p : '')).join('');
    }
  }

  const tokens = clean.split(/\s+/).filter(Boolean);
  let result = '';

  for (let i = 0; i < tokens.length; i++) {
    const raw = tokens[i].replace(/[^a-z\-']/g, '');
    if (!raw) continue;

    // Check two-word letter names like "double u"
    if (i < tokens.length - 1) {
      const nextRaw = tokens[i + 1].replace(/[^a-z\-']/g, '');
      const twoWord = `${raw} ${nextRaw}`;
      if (PHONETIC_LETTER_MAP[twoWord]) {
        result += PHONETIC_LETTER_MAP[twoWord];
        i++;
        continue;
      }
    }

    if (PHONETIC_LETTER_MAP[raw]) {
      result += PHONETIC_LETTER_MAP[raw];
    } else if (raw.length === 1 && /[a-z]/i.test(raw)) {
      result += raw;
    } else {
      // If the engine transcribed the full word matching the target word
      const targetWord = activeQuizList[currentIndex]?.word.toLowerCase() || '';
      const cleanTarget = targetWord.replace(/[^a-z]/g, '');
      if (raw === cleanTarget && baseSpelledLetters === '') {
        return cleanTarget;
      }
      // Otherwise split characters
      for (const char of raw) {
        result += char;
      }
    }
  }

  return result;
}

function toggleMicRecording() {
  if (!speechRecognizer) {
    alert("Speech recognition is not supported in this browser. Please use the keyboard input!");
    return;
  }

  if (isRecording) {
    shouldKeepListening = false;
    speechRecognizer.stop();
  } else {
    shouldKeepListening = true;
    lastCommittedResultIndex = -1;
    try {
      speechRecognizer.start();
    } catch (e) {
      console.warn("Recognition start failed or already active:", e);
    }
  }
}

function updateMicUI(recording) {
  const btn = document.getElementById('mic-btn');
  const label = document.getElementById('mic-status-label');
  const wave = document.getElementById('listening-wave');
  const container = document.getElementById('letter-display');

  if (btn) {
    if (recording) {
      btn.classList.add('recording');
      btn.innerHTML = '🛑';
    } else {
      btn.classList.remove('recording');
      btn.innerHTML = '🎤';
    }
  }

  if (label) {
    label.innerText = recording ? "Listening... Spell clearly now!" : "Click to Spell into Microphone";
    label.style.color = recording ? "#ef4444" : "#334155";
  }

  if (wave) {
    wave.style.display = recording ? "flex" : "none";
  }

  if (container) {
    if (recording) {
      container.classList.add('active-listening');
    } else {
      container.classList.remove('active-listening');
    }
  }
}

// Render letter blocks on screen
function renderLetterBoxes() {
  const container = document.getElementById('letter-display');
  if (!container) return;

  if (!currentSpelledLetters || currentSpelledLetters.length === 0) {
    container.innerHTML = '<span class="letter-placeholder">Press the microphone below and spell the word letter by letter</span>';
    return;
  }

  container.innerHTML = '';
  for (let i = 0; i < currentSpelledLetters.length; i++) {
    const char = currentSpelledLetters[i];
    const box = document.createElement('div');
    if (char === ' ') {
      box.className = 'letter-box space';
      box.innerHTML = '&nbsp;';
    } else {
      box.className = 'letter-box';
      box.textContent = char.toUpperCase();
    }
    container.appendChild(box);
  }

  // Also sync manual input box if open
  const manualInput = document.getElementById('manual-spelling-input');
  if (manualInput) {
    manualInput.value = currentSpelledLetters;
  }
}

function handleBackspaceLetter() {
  if (baseSpelledLetters.length > 0) {
    baseSpelledLetters = baseSpelledLetters.slice(0, -1);
  }
  currentSpelledLetters = baseSpelledLetters;
  renderLetterBoxes();
}

function clearLetters() {
  baseSpelledLetters = "";
  currentSpelledLetters = "";
  lastCommittedResultIndex = -1;
  renderLetterBoxes();
}

function toggleManualInput() {
  const box = document.getElementById('manual-input-container');
  if (!box) return;
  const isHidden = box.style.display === 'none' || !box.style.display;
  box.style.display = isHidden ? 'flex' : 'none';
  if (isHidden) {
    const input = document.getElementById('manual-spelling-input');
    input.value = currentSpelledLetters;
    input.focus();
  }
}

function applyManualInput() {
  const input = document.getElementById('manual-spelling-input');
  if (input) {
    baseSpelledLetters = input.value.trim().toLowerCase();
    currentSpelledLetters = baseSpelledLetters;
    renderLetterBoxes();
  }
}

function handleManualInputKey(event) {
  if (event.key === 'Enter') {
    applyManualInput();
    gradeCurrentSpelling();
  }
}

// ==========================================
// Quiz Flow & Session Logic
// ==========================================
function setWordCount(count) {
  configWordCount = count;
  document.querySelectorAll('.word-count-selector .pill-option[data-count]').forEach(btn => {
    btn.classList.toggle('active', btn.dataset.count === String(count));
  });
  const customInput = document.getElementById('custom-count-input');
  if (customInput && count !== 'custom') {
    customInput.value = '';
  }
}

function setCustomWordCount(val) {
  const num = parseInt(val, 10);
  if (!isNaN(num) && num > 0) {
    configWordCount = num;
    document.querySelectorAll('.word-count-selector .pill-option[data-count]').forEach(btn => {
      btn.classList.remove('active');
    });
  }
}

function setDifficultyFilter(diff) {
  configDifficulty = diff;
  document.querySelectorAll('.diff-filter-card').forEach(card => {
    card.classList.toggle('active', card.classList.contains(`diff-${diff}`));
  });
  updatePoolAvailableNote();
}

function setGradeFilter(grade) {
  configGrade = grade;
  document.querySelectorAll('.word-count-selector .pill-option[data-grade]').forEach(btn => {
    btn.classList.toggle('active', btn.dataset.grade === String(grade));
  });
  updatePoolAvailableNote();
}

function getFilteredPool() {
  return wordsBank.filter(w => {
    // Difficulty match
    if (configDifficulty !== 'all' && w.difficulty !== configDifficulty) {
      return false;
    }
    // Grade match
    if (configGrade !== 'all' && String(w.grade) !== String(configGrade)) {
      return false;
    }
    return true;
  });
}

function shuffleArray(array) {
  const copy = [...array];
  for (let i = copy.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [copy[i], copy[j]] = [copy[j], copy[i]];
  }
  return copy;
}

function startQuizSession(customList = null) {
  if (customList && customList.length > 0) {
    activeQuizList = shuffleArray(customList);
  } else {
    const pool = getFilteredPool();
    if (pool.length === 0) {
      alert("No words match the selected filters! Please select another difficulty or grade.");
      return;
    }

    const shuffled = shuffleArray(pool);
    const count = (configWordCount === 'all') ? shuffled.length : Math.min(Number(configWordCount) || 10, shuffled.length);
    activeQuizList = shuffled.slice(0, count);
  }

  currentIndex = 0;
  currentScore = 0;
  currentSessionResults = [];

  document.getElementById('setup-screen').style.display = 'none';
  document.getElementById('results-screen').style.display = 'none';
  document.getElementById('quiz-screen').style.display = 'block';

  loadCurrentWord();
}

function loadCurrentWord() {
  if (currentIndex >= activeQuizList.length) {
    finishQuizSession();
    return;
  }

  const currentItem = activeQuizList[currentIndex];
  shouldKeepListening = false;
  if (isRecording && speechRecognizer) {
    speechRecognizer.stop();
  }
  baseSpelledLetters = "";
  currentSpelledLetters = "";
  lastCommittedResultIndex = -1;
  renderLetterBoxes();

  // Reset clues & feedback
  const clueBox = document.getElementById('clue-box');
  clueBox.style.display = 'none';
  clueBox.innerHTML = '';

  const feedbackBanner = document.getElementById('feedback-banner');
  feedbackBanner.style.display = 'none';

  // Update Progress & Score
  const total = activeQuizList.length;
  document.getElementById('progress-indicator').innerText = `Word ${currentIndex + 1} of ${total}`;
  const pct = total > 0 ? Math.round(((currentIndex) / total) * 100) : 0;
  document.getElementById('quiz-progress-bar').style.width = `${pct}%`;
  document.getElementById('current-score-badge').innerText = `Score: ${currentScore} / ${currentIndex} (${currentIndex > 0 ? Math.round((currentScore / currentIndex) * 100) : 0}%)`;

  // Badges
  const diffBadge = document.getElementById('badge-difficulty');
  diffBadge.className = `badge badge-${currentItem.difficulty}`;
  const diffIcons = { easy: '🌸 Easy (Pink)', middle: '🌊 Middle (Blue)', hard: '🍇 Hard (Purple)', unmarked: '⚪ Unmarked' };
  diffBadge.innerText = diffIcons[currentItem.difficulty] || currentItem.difficulty;

  document.getElementById('badge-grade').innerText = `Grade ${currentItem.grade}`;
  document.getElementById('badge-pos').innerText = currentItem.pos || 'noun';

  // Read word out automatically after short pause
  setTimeout(() => {
    pronounceCurrentWord();
  }, 400);
}

function pronounceCurrentWord() {
  const currentItem = activeQuizList[currentIndex];
  if (!currentItem) return;
  speakText(`Your word is: ${currentItem.word}`, 0.9);
}

function speakCurrentWordSlowly() {
  const currentItem = activeQuizList[currentIndex];
  if (!currentItem) return;
  speakText(currentItem.word, 0.65);
}

// Mask target word and its variants/inflections in clue text so the spelling is never revealed
function maskWordInText(text, word, alternatives = []) {
  if (!text || !word) return text || '';

  const wordsToMask = [word, ...(alternatives || [])];
  let masked = text;

  wordsToMask.forEach(w => {
    if (!w) return;
    const cleanWord = w.trim();
    // Escape regex special chars
    const escaped = cleanWord.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');

    // Match word boundaries and common English suffixes (plurals, verb endings)
    const regex = new RegExp(`\\b${escaped}(?:s|es|ed|ing|d|ly|al)?\\b`, 'gi');
    masked = masked.replace(regex, '<span class="blanked-word">________</span>');

    // For multi-word terms (e.g. 'salicylic acid', 'a cappella', 'bogong moth')
    if (cleanWord.includes(' ') || cleanWord.includes('-')) {
      const parts = cleanWord.split(/[\s-]+/).filter(p => p.length >= 3);
      parts.forEach(p => {
        const pEsc = p.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
        const pRegex = new RegExp(`\\b${pEsc}(?:s|es|ed|ing|d)?\\b`, 'gi');
        masked = masked.replace(pRegex, '<span class="blanked-word">________</span>');
      });
    }
  });

  return masked;
}

let audioOnlyClues = false;

function toggleAudioOnlyPreference(val) {
  audioOnlyClues = val;
  try {
    localStorage.setItem('bee_audio_only_clues', val ? 'true' : 'false');
  } catch (e) {}

  // Sync checkboxes across UI
  const quizCb = document.getElementById('audio-only-toggle');
  const setupCb = document.getElementById('setup-audio-only-toggle');
  if (quizCb) quizCb.checked = val;
  if (setupCb) setupCb.checked = val;
}

function revealClueText() {
  const rev = document.getElementById('revealed-clue-content');
  const btn = document.getElementById('reveal-clue-btn');
  if (rev) rev.style.display = 'block';
  if (btn) btn.style.display = 'none';
}

function toggleClue(type) {
  const currentItem = activeQuizList[currentIndex];
  if (!currentItem) return;

  const box = document.getElementById('clue-box');
  box.style.display = 'block';

  const maskedDef = maskWordInText(currentItem.def, currentItem.word, currentItem.alternatives);
  const maskedSentence = maskWordInText(currentItem.sentence, currentItem.word, currentItem.alternatives);

  if (type === 'definition') {
    speakText(`Definition: ${currentItem.def}`);
    if (audioOnlyClues) {
      box.innerHTML = `
        <div style="display:flex; justify-content:space-between; align-items:center;">
          <span>🔊 <em>Definition read aloud (audio-only)</em></span>
          <button id="reveal-clue-btn" class="btn btn-outline" style="padding:2px 8px; font-size:0.75rem;" onclick="revealClueText()">Show masked text</button>
        </div>
        <div id="revealed-clue-content" style="display:none; margin-top:8px; padding-top:6px; border-top:1px dashed #cbd5e1;">
          <strong>Definition:</strong> ${maskedDef}
        </div>
      `;
    } else {
      box.innerHTML = `<strong>Definition:</strong> ${maskedDef}`;
    }
  } else if (type === 'sentence') {
    speakText(`In a sentence: ${currentItem.sentence}`);
    if (audioOnlyClues) {
      box.innerHTML = `
        <div style="display:flex; justify-content:space-between; align-items:center;">
          <span>🔊 <em>Sentence read aloud (audio-only)</em></span>
          <button id="reveal-clue-btn" class="btn btn-outline" style="padding:2px 8px; font-size:0.75rem;" onclick="revealClueText()">Show masked text</button>
        </div>
        <div id="revealed-clue-content" style="display:none; margin-top:8px; padding-top:6px; border-top:1px dashed #cbd5e1;">
          <strong>Sentence:</strong> "${maskedSentence}"
        </div>
      `;
    } else {
      box.innerHTML = `<strong>Sentence:</strong> "${maskedSentence}"`;
    }
  }
}

// ==========================================
// Grading
// ==========================================
function normalizeWord(str) {
  if (!str) return '';
  return str.toLowerCase()
    .normalize("NFD").replace(/[\u0300-\u036f]/g, "") // remove accents (e.g. éclair -> eclair)
    .replace(/[^a-z]/g, ""); // strip hyphens, spaces for flexible checking
}

function gradeCurrentSpelling() {
  shouldKeepListening = false;
  if (isRecording && speechRecognizer) {
    speechRecognizer.stop();
  }

  const currentItem = activeQuizList[currentIndex];
  if (!currentItem) return;

  const userRaw = (currentSpelledLetters || baseSpelledLetters).trim();
  if (!userRaw) {
    alert("Please say or type your spelling before submitting!");
    return;
  }

  const userNormalized = normalizeWord(userRaw);
  const targetNormalized = normalizeWord(currentItem.word);

  // Check target and alternatives
  let isCorrect = (userNormalized === targetNormalized);
  if (!isCorrect && currentItem.alternatives) {
    for (const alt of currentItem.alternatives) {
      if (userNormalized === normalizeWord(alt)) {
        isCorrect = true;
        break;
      }
    }
  }

  if (isCorrect) {
    currentScore++;
  }

  // Record in round results
  currentSessionResults.push({
    word: currentItem.word,
    grade: currentItem.grade,
    difficulty: currentItem.difficulty,
    userSpelling: userRaw,
    isCorrect: isCorrect,
    alternatives: currentItem.alternatives || []
  });

  // Display feedback banner
  showFeedbackBanner(isCorrect, currentItem, userRaw);
}

function showFeedbackBanner(isCorrect, item, userSpelling) {
  const banner = document.getElementById('feedback-banner');
  const title = document.getElementById('feedback-title');
  const details = document.getElementById('feedback-details');
  const speechAction = document.getElementById('feedback-speech-action');

  banner.style.display = 'block';
  banner.className = `feedback-box ${isCorrect ? 'correct' : 'incorrect'}`;

  playChime(isCorrect);

  if (isCorrect) {
    title.innerHTML = `🎉 Correct! Outstanding Job!`;
    details.innerHTML = `You spelled: <strong class="spelled-comparison">${userSpelling.toUpperCase()}</strong>`;
    speechAction.innerHTML = '';
    triggerConfetti();

    // Congratulatory voice
    speakText("Correct! That is right.", 1.0);
  } else {
    title.innerHTML = `❌ Not Quite!`;
    details.innerHTML = `
      <div>You spelled: <strong class="spelled-comparison">${userSpelling.toUpperCase()}</strong></div>
      <div>Correct spelling: <strong class="spelled-comparison" style="color:#047857; background:#d1fae5;">${item.word.toUpperCase()}</strong></div>
      ${item.alternatives && item.alternatives.length ? `<div style="font-size:0.8rem; margin-top:4px;">(Alternative accepted: ${item.alternatives.join(', ')})</div>` : ''}
    `;

    speechAction.innerHTML = `
      <button class="btn btn-voice" onclick="speakLetterByLetter('${item.word}')">
        🔊 Hear Correct Spelling Again
      </button>
    `;

    // Read back correct spelling letter by letter
    setTimeout(() => {
      speakLetterByLetter(item.word);
    }, 300);
  }

  // Focus next button
  const nextBtn = document.getElementById('next-word-btn');
  if (nextBtn) nextBtn.focus();
}

function proceedToNextWord() {
  currentIndex++;
  loadCurrentWord();
}

function confirmExitQuiz() {
  if (confirm("Are you sure you want to exit this spelling session?")) {
    document.getElementById('quiz-screen').style.display = 'none';
    document.getElementById('setup-screen').style.display = 'block';
  }
}

// ==========================================
// Results & History
// ==========================================
function finishQuizSession() {
  document.getElementById('quiz-screen').style.display = 'none';
  document.getElementById('results-screen').style.display = 'block';

  const total = activeQuizList.length;
  const pct = total > 0 ? Math.round((currentScore / total) * 100) : 0;

  document.getElementById('final-score-percent').innerText = `${pct}%`;
  document.getElementById('final-score-fraction').innerText = `${currentScore} / ${total} Correct`;

  const icon = document.getElementById('results-icon');
  const headline = document.getElementById('results-headline');
  const subtext = document.getElementById('results-subtext');

  if (pct === 100) {
    icon.innerText = '🏆';
    headline.innerText = 'Flawless Victory!';
    subtext.innerText = 'You spelled every single word correctly! Incredible job!';
    triggerConfetti();
  } else if (pct >= 80) {
    icon.innerText = '🌟';
    headline.innerText = 'Fantastic Spelling!';
    subtext.innerText = 'You mastered most of the words in this round!';
    triggerConfetti();
  } else {
    icon.innerText = '💪';
    headline.innerText = 'Great Effort!';
    subtext.innerText = 'Practice makes permanent. Keep going and master the tricky ones!';
  }

  // Count missed
  const missedWords = currentSessionResults.filter(r => !r.isCorrect);
  document.getElementById('missed-count-span').innerText = missedWords.length;
  document.getElementById('retry-missed-btn').style.display = missedWords.length > 0 ? 'inline-flex' : 'none';

  // Table summary
  const tableBody = document.getElementById('results-table-body');
  tableBody.innerHTML = '';
  currentSessionResults.forEach(res => {
    const tr = document.createElement('tr');
    tr.innerHTML = `
      <td><strong>${res.word}</strong></td>
      <td>Grade ${res.grade}</td>
      <td><span class="badge badge-${res.difficulty}">${res.difficulty}</span></td>
      <td style="font-family:monospace; font-weight:700;">${res.userSpelling.toUpperCase()}</td>
      <td>${res.isCorrect ? '<span style="color:#10b981; font-weight:800;">✓ Correct</span>' : '<span style="color:#ef4444; font-weight:800;">✗ Missed</span>'}</td>
      <td><button class="btn btn-outline" style="padding:0.25rem 0.5rem; font-size:0.75rem;" onclick="speakLetterByLetter('${res.word}')">🔊 Listen</button></td>
    `;
    tableBody.appendChild(tr);
  });

  // Save to statistics
  saveSessionToStats(total, currentScore, pct);
}

function retryMissedWords() {
  const missedItems = currentSessionResults.filter(r => !r.isCorrect);
  if (missedItems.length === 0) return;

  const retryList = missedItems.map(m => wordsBank.find(w => w.word.toLowerCase() === m.word.toLowerCase())).filter(Boolean);
  startQuizSession(retryList);
}

function startNewSessionSetup() {
  document.getElementById('results-screen').style.display = 'none';
  document.getElementById('setup-screen').style.display = 'block';
}

function saveSessionToStats(total, score, pct) {
  try {
    const history = JSON.parse(localStorage.getItem('bee_session_history') || '[]');
    history.unshift({
      date: new Date().toLocaleDateString() + ' ' + new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      total: total,
      score: score,
      pct: pct,
      difficulty: configDifficulty,
      grade: configGrade
    });
    // Keep last 30 sessions
    localStorage.setItem('bee_session_history', JSON.stringify(history.slice(0, 30)));
    loadStats();
  } catch (e) {}
}

function loadStats() {
  try {
    const history = JSON.parse(localStorage.getItem('bee_session_history') || '[]');
    const totalSessions = history.length;
    let totalWords = 0;
    let totalScore = 0;

    history.forEach(h => {
      totalWords += h.total || 0;
      totalScore += h.score || 0;
    });

    const accuracy = totalWords > 0 ? Math.round((totalScore / totalWords) * 100) : 0;

    const elSessions = document.getElementById('stat-total-tests');
    const elWords = document.getElementById('stat-total-words');
    const elAcc = document.getElementById('stat-accuracy');
    const container = document.getElementById('history-container');

    if (elSessions) elSessions.innerText = totalSessions;
    if (elWords) elWords.innerText = totalWords;
    if (elAcc) elAcc.innerText = `${accuracy}%`;

    if (container && history.length > 0) {
      container.innerHTML = `
        <table class="breakdown-table">
          <thead>
            <tr>
              <th>Date</th>
              <th>Words</th>
              <th>Score</th>
              <th>Accuracy</th>
              <th>Filter</th>
            </tr>
          </thead>
          <tbody>
            ${history.map(h => `
              <tr>
                <td>${h.date}</td>
                <td>${h.total} words</td>
                <td>${h.score} / ${h.total}</td>
                <td><strong>${h.pct}%</strong></td>
                <td>${h.difficulty} / Grade ${h.grade}</td>
              </tr>
            `).join('')}
          </tbody>
        </table>
      `;
    }
  } catch (e) {}
}

// ==========================================
// Word Bank Tab
// ==========================================
function renderWordBank() {
  const grid = document.getElementById('word-card-grid');
  if (!grid) return;

  const searchQuery = (document.getElementById('bank-search')?.value || '').toLowerCase().trim();
  const gradeFilter = document.getElementById('bank-grade-filter')?.value || 'all';
  const diffFilter = document.getElementById('bank-diff-filter')?.value || 'all';

  const filtered = wordsBank.filter(item => {
    if (gradeFilter !== 'all' && String(item.grade) !== gradeFilter) return false;
    if (diffFilter !== 'all' && item.difficulty !== diffFilter) return false;
    if (searchQuery) {
      const matchWord = item.word.toLowerCase().includes(searchQuery);
      const matchDef = (item.def || '').toLowerCase().includes(searchQuery);
      if (!matchWord && !matchDef) return false;
    }
    return true;
  });

  grid.innerHTML = '';
  filtered.forEach(item => {
    const card = document.createElement('div');
    card.className = 'word-tile';
    card.innerHTML = `
      <div>
        <div class="word-tile-header">
          <div>
            <div class="word-title">${item.word}</div>
            <div style="font-size:0.75rem; color:#64748b; font-weight:600;">
              Grade ${item.grade} • ${item.pos || 'noun'}
            </div>
          </div>
          <button class="btn btn-outline" style="padding:0.35rem 0.6rem; font-size:0.85rem;" onclick="speakLetterByLetter('${item.word}')" title="Pronounce and spell">
            🔊
          </button>
        </div>
        <div class="word-tile-def">${item.def}</div>
        <div style="font-size:0.75rem; font-style:italic; color:#64748b; margin-bottom:0.75rem;">"${item.sentence}"</div>
      </div>
      <div class="word-tile-footer">
        <span class="badge badge-${item.difficulty}">${item.difficulty}</span>
        <select class="difficulty-picker-select" onchange="saveCustomDifficulty('${item.word}', this.value); renderWordBank();">
          <option value="easy" ${item.difficulty === 'easy' ? 'selected' : ''}>🌸 Easy (Pink)</option>
          <option value="middle" ${item.difficulty === 'middle' ? 'selected' : ''}>🌊 Middle (Blue)</option>
          <option value="hard" ${item.difficulty === 'hard' ? 'selected' : ''}>🍇 Hard (Purple)</option>
          <option value="unmarked" ${item.difficulty === 'unmarked' ? 'selected' : ''}>⚪ Unmarked</option>
        </select>
      </div>
    `;
    grid.appendChild(card);
  });
}

// Navigation Tabs
function switchTab(tabId) {
  document.querySelectorAll('.nav-tab-btn').forEach(b => b.classList.remove('active'));
  document.getElementById(`tab-${tabId}`)?.classList.add('active');

  document.getElementById('quiz-tab-content').style.display = (tabId === 'quiz') ? 'block' : 'none';
  document.getElementById('bank-tab-content').style.display = (tabId === 'bank') ? 'block' : 'none';
  document.getElementById('stats-tab-content').style.display = (tabId === 'stats') ? 'block' : 'none';

  if (tabId === 'bank') renderWordBank();
  if (tabId === 'stats') loadStats();
}

// Keyboard Shortcuts
function handleGlobalKeydown(e) {
  // If user is currently typing in an input box, let normal typing happen
  if (['INPUT', 'SELECT', 'TEXTAREA'].includes(e.target.tagName)) return;

  const quizScreen = document.getElementById('quiz-screen');
  if (quizScreen && quizScreen.style.display !== 'none') {
    if (e.key === 'r' || e.key === 'R') {
      pronounceCurrentWord();
    } else if (e.key === ' ' && !e.target.closest('button')) {
      e.preventDefault();
      toggleMicRecording();
    } else if (e.key === 'Enter') {
      const feedbackBanner = document.getElementById('feedback-banner');
      if (feedbackBanner && feedbackBanner.style.display !== 'none') {
        proceedToNextWord();
      } else {
        gradeCurrentSpelling();
      }
    }
  }
}

// ==========================================
// Confetti Animation Effect
// ==========================================
function triggerConfetti() {
  const canvas = document.getElementById('confetti-canvas');
  if (!canvas) return;
  const ctx = canvas.getContext('2d');
  canvas.width = window.innerWidth;
  canvas.height = window.innerHeight;

  const confettiPieces = [];
  const colors = ['#f43f5e', '#0284c7', '#8b5cf6', '#f59e0b', '#10b981', '#fbbf24'];

  for (let i = 0; i < 90; i++) {
    confettiPieces.push({
      x: Math.random() * canvas.width,
      y: Math.random() * canvas.height * 0.4,
      w: Math.random() * 8 + 4,
      h: Math.random() * 8 + 4,
      color: colors[Math.floor(Math.random() * colors.length)],
      vy: Math.random() * 4 + 2,
      vx: (Math.random() - 0.5) * 3,
      rotation: Math.random() * 360,
      vRot: (Math.random() - 0.5) * 8
    });
  }

  let frames = 0;
  function animate() {
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    confettiPieces.forEach(p => {
      p.y += p.vy;
      p.x += p.vx;
      p.rotation += p.vRot;
      ctx.save();
      ctx.translate(p.x, p.y);
      ctx.rotate((p.rotation * Math.PI) / 180);
      ctx.fillStyle = p.color;
      ctx.fillRect(-p.w / 2, -p.h / 2, p.w, p.h);
      ctx.restore();
    });

    frames++;
    if (frames < 120) {
      requestAnimationFrame(animate);
    } else {
      ctx.clearRect(0, 0, canvas.width, canvas.height);
    }
  }
  animate();
}
